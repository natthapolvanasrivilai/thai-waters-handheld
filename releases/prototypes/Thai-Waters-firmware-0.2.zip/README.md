# Thai Waters · Firmware 0.2

For Waveshare ESP32-S3-Touch-LCD-3.5B (31137), QMI8658, ES8311 and a right-side AS5600 reel at 0x36. The optional DRV2605L at 0x5A adds haptics. The game runs without the haptic module. The bench guide in this folder includes wiring, optional BOM and candidate placement.

## Flash and play

Extract the ZIP. With the board connected by a USB data cable and the serial monitor closed, substitute the actual port for COM7. Flashing replaces the active game. These four writes leave the existing NVS partition in place with the project’s v0.1 partition layout.

~~~powershell
python -m pip install esptool==5.3.0
.\Flash-Thai-Waters.ps1 -Port COM7
~~~

On other operating systems use the corresponding serial port in the command below.

~~~sh
python -m esptool --chip esp32s3 --port COM7 write-flash --flash-mode dio --flash-freq 80m --flash-size 16MB 0x0 flash/bootloader.bin 0x8000 flash/partitions.bin 0xe000 flash/boot_app0.bin 0x10000 flash/ThaiWaters.bin
~~~

Hold BOOT, tap RESET, then release BOOT if the board needs download mode. Boot diagnostics are available at 115200 baud. On first boot with a new board, follow the two-pose calibration. A v0.1 installation with saved poses and sound preferences reuses them. Gameplay catches in v0.1 were session-only. Thai Waters starts a new persistent field book.

Raise the rod and sweep forward to cast. A small nibble moves the bobber. Hold until the float goes under and the bite cue fires, then lift. Wind to bring in line and ease off during surges. The fish has a pale outline in the fight view and a dark specimen card when landed. The right-side reel direction can be reversed in the bench screen. **Options → Touch practice** allows tap-to-cast, tap-to-hook and quarter-turn tap retrieval on the bare board.

## Waters and progress

| Destination | Water | Original score |
|---|---|---|
| Chiang Mai Pond | An imagined lotus pond in Chiang Mai | Lotus at Dawn |
| Chao Phraya | River, central Thailand | Ferry Lanterns |
| Cheow Lan Lake | Reservoir, southern Thailand | Karst Echo |
| Nong Khai Mekong | River, northeastern Thailand | Mekong Afterglow |

Each destination has a separate original pixel scene, score, and ten-species catch pool. The 40 entries use game-designed lengths, rarity and location assignments. The field book tracks each species' count and longest catch. Each water draws three common, three uncommon, two rare, one epic and one legendary species with relative weights of 16, 7, 3, 2 and 1 per species. This makes a legendary catch about 1 in 78 casts that draw a fish. The included field-book CSV lists every entry and weight.

Open **Options → Journey + tackle** for the boatkeeper's story, next goal, available points and build choices. First discovery earns one point. Each subsequent group of three new species earns another. Story chapters open at 1 discovery, 5 discoveries, 12 across at least two waters, 26 across all four, and a complete atlas. All waters are available from the start. The first three chapters earned unlock the first, second and third ranks respectively. Spending points changes the actual fishing rules.

| Upgrade | Per rank | Rank 3 |
|---|---|---|
| Hook timing | +150 ms to the 1.45 s bite window | 1.90 s window |
| Reel gearing | +12% line retrieval per signed knob turn | 1.36× line movement |
| Line control | 10% less tension added while winding | 30% less tension gain |

Ranks cost 1, then 2, then 3 points per path. A complete field book earns 14 points. All nine ranks together cost 18, so builds differ between players. Refund and confirm to reassign all spent points while keeping the journal. Repeats improve catch counts and can set a new personal best. The board writes the book and ranks together on a landing or tackle change. Desktop practice keeps its own browser-local progress.

**Sound + controls** sets music arrangement and volume, bite alert mode and bite volume independently. Each destination has distinct melodic, rhythmic and bass material. Adaptive mode adds the fight layer. Drift, Melody and Off are also available. Haptic strength is a separate persistent setting on the bench page and defaults to Off.

## Build and verification

The four required board libraries are included. The source sketch directory retains its v0.1 name for existing build workflows. Use Arduino CLI 1.3.1 and Arduino-ESP32 3.3.10. Waveshare's library revision is c7dd63c70258da7e3b6dae0c621f30ca62b1e1c9.

~~~sh
arduino-cli core update-index --additional-urls https://espressif.github.io/arduino-esp32/package_esp32_index.json
arduino-cli core install esp32:esp32@3.3.10 --additional-urls https://espressif.github.io/arduino-esp32/package_esp32_index.json
arduino-cli compile --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,PartitionScheme=app3M_fat9M_16MB,USBMode=hwcdc,CDCOnBoot=cdc" --libraries libraries WillowCreek
~~~

The release contains the target build result, image inspection, per-segment SHA-256 values, model clearances and test logs. Native C++17 tests exercise motion, reel, four scores, 200,000 weighted casts, tackle effects, persistence and the firmware bench screen with injected peripherals. Compile tests/panel.cpp with tests/shims on the include path. The browser test landed a fish, bought a reel upgrade, reloaded the saved book and refunded the points. The physical board, speaker and motor were unavailable during this build.

[Waveshare board and examples](https://github.com/waveshareteam/ESP32-S3-Touch-LCD-3.5B/tree/c7dd63c70258da7e3b6dae0c621f30ca62b1e1c9)
