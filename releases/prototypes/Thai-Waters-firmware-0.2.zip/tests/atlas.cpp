#include "../WillowCreek/Rumble.h"
#include <cassert>
#include <cstdio>
#include <cstring>
using namespace creek;
int main(){
 int counts[fishCount]{};
 for(int i=0;i<siteCount;i++){
  Game g;g.site=i;
  for(int n=0;n<50000;n++){
   g.enter(Phase::Ready);g.tick(16,true,false,0);
   assert(g.fish/10==i);const auto& s=catalog[g.fish];
   assert(g.length>=s.low && g.length<=s.high);counts[g.fish]++;
  }
  for(int k=0;k<10;k++)assert(counts[10*i+k]>0);
  assert(counts[10*i]>counts[10*i+6]*3 && counts[10*i+6]>counts[10*i+9]*2);
 }
 Game g;auto& p=g.progress;
 assert(p.points()==0 && !p.upgrade(0));
 auto catchFish=[&](int id,int length){g.phase=Phase::Fight;g.fish=id;g.length=length;g.line=.01f;g.target=6;g.tick(16,false,false,.1f);assert(g.phase==Phase::Landed);};
 catchFish(0,21);assert(g.pointsAwarded==1 && p.book.discovered()==1 && p.chapter()==1);
 catchFish(0,16);assert(!g.newEntry && !g.personalBest && p.book.entries[0].count==2 && p.book.entries[0].best==21);
 assert(p.upgrade(0)&&p.points()==0&&!p.upgrade(0));
 g.enter(Phase::Bite);g.tick(1530,false,true,0);assert(g.phase==Phase::Fight);
 p.retrain();assert(p.points()==1&&p.upgrade(1));g.line=3;g.heat=0;g.tick(0,false,false,.5f);assert(std::abs(g.line-2.44f)<.001);
 p.retrain();assert(p.upgrade(2));g.heat=0;g.tick(0,false,false,.5f);assert(std::abs(g.heat-.09f)<.001);
 for(int i=1;i<40;i++)catchFish(i,catalog[i].low);
 assert(p.book.discovered()==40 && p.waters()==4 && p.chapter()==5 && p.points()==13);
 p.retrain();assert(p.points()==14);assert(p.upgrade(0)&&p.upgrade(0)&&p.upgrade(0)&&!p.upgrade(0));
 Progress loaded;memcpy(&loaded,&p,sizeof(p));assert(loaded.points()==8&&loaded.book.entries[0].count==2);
 RumblePlan plan;g.enter(Phase::Waiting);g.waitMs=3500;g.age=2550;
 assert(plan.tick(g,2500,true)==Pulse::Tease && plan.tick(g,2520,true)==Pulse::None);
 g.enter(Phase::Bite);assert(plan.tick(g,3300,true)==Pulse::Bite && plan.tick(g,3320,true)==Pulse::None);
 g.enter(Phase::Fight);g.heat=.98;assert(plan.tick(g,5330,true)==Pulse::Pull);
 assert(plan.tick(g,8000,false)==Pulse::None);
 puts("PASS 200000 weighted casts, all 40 species, record book, chapter gates, point accounting, three effective upgrades, refund, persistence layout and distinct tease/bite/pull events.");
}
