#include "../WillowCreek/WillowCreek.ino"
#include <cassert>
#include <cstdio>
uint32_t testClock=0;Arduino_Canvas screen;bool screenOK=true,imuOK=true,powerOK=true;
creek::Vec inputG{0,0,1};int encoder=4070,px=0,py=0,cuePulses=0,motorPulses=0;
bool touched=false;Field magnet=Field::Good;SoundSettings lastMix;
void beginBoard(){} bool acceleration(creek::Vec& v){v=inputG;return true;}
Field readWheel(int& a){a=encoder;return magnet;}
bool touchPoint(int& x,int& y){x=px;y=py;return touched;}
void beginScene(){}void paint(const View&){}
bool startSound(){return true;}void setSound(const SoundSettings& s,bool,bool cue){lastMix=s;if(cue)++cuePulses;}
bool initRumble(){return true;}bool driveRumble(Pulse p,uint8_t level,float){if(p!=Pulse::None && level)++motorPulses;return true;}void stopRumble(){}
void step(int count){while(count--){testClock+=16;loop();}}
void tap(int x,int y){px=x;py=y;touched=true;step(3);touched=false;step(4);}
int main(){
 setup();step(42);assert(view.page==Page::Rest&&view.stable);
 tap(120,250);inputG={0,.64f,.7684f};step(55);tap(125,250);assert(view.calibrated&&view.page==Page::Play);
 inputG={0,0,1};step(30);tap(420,16);tap(65,176);assert(view.page==Page::Bench);
 step(25);inputG={0,.64f,.7684f};step(20);inputG={0,0,1};step(24);
 assert(view.casts==1&&view.lifts==1&&view.degrees<2 && view.game.phase==Phase::Ready);
 encoder=35;step(1);assert(view.raw==35 && view.direction==1 && view.turns>0);
 tap(32,181);assert(view.sound.reverse);encoder=125;step(1);assert(view.direction==-1&&view.turns<0);
 magnet=Field::Weak;step(1);assert(view.raw==-1);magnet=Field::Good;encoder=4000;step(1);assert(view.turns>-.1);
 view.sound.cue=1;tap(26,211);int level=view.sound.cueVolume;tap(342,211);assert(cuePulses==1&&lastMix.cue==0&&lastMix.cueVolume==level);
 step(35);assert(lastMix.cue==1);tap(53,251);tap(345,250);assert(motorPulses==1);
 tap(427,17);tap(23,57);tap(22,180);assert(view.page==Page::Play && view.game.site==2 && view.sound.site==2);
 view.game.phase=Phase::Fight;view.game.fish=20;view.game.line=.01f;view.game.target=6;view.game.length=35;view.practice=true;
 tap(23,287);assert(view.game.phase==Phase::Landed && store.getBytesLength("atlas-2")==sizeof(Progress));
 tap(425,17);tap(88,145);assert(view.page==Page::Journey);tap(60,162);assert(view.game.progress.rank[1]==1);
 view.game.progress=Progress{};restore();assert(view.game.progress.rank[1]==1&&view.game.progress.book.entries[20].count==1&&view.calibrated);
 puts("PASS sketch-loop bench calibration, live cast/lift counts, signed wrapped encoder and reversal, magnet recovery, independent cue audition, rumble audition, travel, upgrade and saved-state restore using injected peripherals.");
}
