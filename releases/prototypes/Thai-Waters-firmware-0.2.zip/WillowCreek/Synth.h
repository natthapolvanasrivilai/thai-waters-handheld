#pragma once
#include "Sound.h"
#include "Score.h"
#include <algorithm>
#include <cmath>
#include <cstddef>
class CreekSynth {
  struct Voice {uint32_t phase=0, step=0; int age=0,length=0,amp=0;};
  int16_t sineTable[256]{};
  Voice voice[4]{};
  int playing=-1; unsigned cursor=0,clock=0,cueAge=10000;
  uint32_t cuePhase=0;
public:
  void begin(){for(int i=0;i<256;i++)sineTable[i]=std::lround(std::sin(i*6.2831853f/256)*32760);}
  void render(int16_t* buffer,size_t frames,const SoundSettings& s,bool chase,bool trigger){
    if(playing!=s.site){playing=s.site;cursor=clock=0;for(auto& v:voice)v=Voice{};} const Note* notes=songs[playing]; if(trigger){cueAge=0;cuePhase=0;}
    for(size_t i=0;i<frames;i++){
      while(cursor<songSizes[playing] && notes[cursor].start==clock){
        const Note& n=notes[cursor++];
        voice[n.voice]={0,n.step,0,n.duration,n.level};
      }
      int music=0;
      for(int v=0;v<4;v++){
        Voice& o=voice[v];
        if(o.age>=o.length)continue;
        int env=std::min(96,o.age)*std::min(192,o.length-o.age)/192;
        int value=sineTable[o.phase>>24]*o.amp/32768;
        if(s.music!=3 && (v!=1 || s.music!=1) && (v!=3 || (s.music==0 && chase)))music+=value*env/96;
        o.age++;o.phase+=o.step;
      }
      int pcm=music*s.volume/(cueAge<6200?12:4);
      bool first=cueAge<1600,second=cueAge>=2300 && cueAge<5300;
      if((first||second) && s.cue!=1){
        int t=first?int(cueAge):int(cueAge)-2300, len=first?1600:3000;
        int env=std::min(80,t)*std::min(180,len-t)/180;
        pcm+=sineTable[cuePhase>>24]*s.cueVolume/12*env/80;
        cuePhase+=first?265140575u:397275598u; // B5 then F#6
      }
      if(cueAge<10000)cueAge++;
      buffer[i*2]=buffer[i*2+1]=std::max(-32760,std::min(32760,pcm));
      if(++clock==songEnds[playing]){clock=0;cursor=0;}
    }
  }
};


