#include "Scene.h"
#include "Landscape.h"
#include "FishArt.h"
#include <cstdio>
#include <cstring>
using creek::Phase;
namespace {
constexpr int ink=0x19e7,paper=0xe70f,white=0xff9b,gold=0xf50c,green=0x94f2,red=0xf386;
uint16_t* background=nullptr;
int cachedSite=-1;
void landscape(int site){
  for(int y=0;y<160;y++)for(int x=0;x<240;x++){
    int b=places[site][y*120+x/2];
    screen.fillRect(x*2,y*2,2,2,colors[site][(x&1)?b&15:b>>4]);
  }
}
void label(int x,int y,const char* s,int col=white,int size=2){
  screen.setTextSize(size);screen.setTextColor(col);screen.setCursor(x,y);screen.print(s);
}
void fish(int x,int y,int k,int kind){
  for(int row=0;row<25;row++){
    int start=0,prev=0;
    for(int col=0;col<=48;col++){
      int packed=col==48?0:fishArt[kind][row*24+col/2];
      int c=col&1?packed&15:packed>>4;
      if(c!=prev){if(prev)screen.fillRect(x+start*k,y+row*k,(col-start)*k,k,fishInk[kind][prev]);start=col;prev=c;}
    }
  }
}
const char* wheelFault(Field f){
  switch(f){case Field::Weak:return "Magnet too weak";case Field::Strong:return "Magnet too strong";
  case Field::NoMagnet:return "Center magnet over reel sensor";default:return "Connect AS5600 reel to J8";}
}
void top(const View& v){
  screen.fillRect(0,0,480,33,ink);label(10,9,creek::sites[v.game.site].name,paper);
  char t[36];snprintf(t,sizeof(t),"%s  %d",v.practice?"PRACTICE":"CATCH",v.game.catches);
  label(195,9,t,green);label(382,9,"OPTIONS",white);
}
void options(const View& v){
  const char* music[]={"Adaptive","Drift","Melody","Off"};
  const char* volume[]={"Off","Low","Medium","High"};
  const char* cues[]={"Light + tone","Light","Tone"};
  const char* rows[]={"Music","Music volume","Bite cue","Cue volume","Reel direction","Controls","Rod calibration"};
  const char* vals[]={music[v.sound.music],volume[v.sound.volume],cues[v.sound.cue],volume[v.sound.cueVolume],
    v.sound.reverse?"Reversed":"Forward",v.practice?"Touch practice":"Motion + knob","Set two poses"};
  screen.fillScreen(ink);label(14,12,"SOUND + CONTROLS",paper);label(397,12,"DONE",gold);
  for(int i=0;i<7;i++){
    int y=42+37*i;screen.drawFastHLine(14,y,450,0x428c);label(15,y+10,rows[i],white);label(258,y+10,vals[i],green);
  }
  label(14,305,v.audio?"Tap a row to change it.":"Audio unavailable - check codec.",gold,1);
}
void calibration(const View& v){
  bool rest=v.page==Page::Rest;
  screen.fillScreen(ink);label(18,17,"ROD CALIBRATION",green);label(380,17,"OPTIONS",white);
  label(18,74,rest?"1  Playing position":"2  Raised rod",paper,3);
  label(18,137,rest?"Hold the screen as you play.":"Lift the far edge 30-50 degrees.");
  label(18,172,v.badPose?"Try a larger, steady lift.":!v.motion?"IMU unavailable. Try practice.":v.stable?"Steady. Tap to capture.":"Hold still for half a second.",gold);
  screen.fillRoundRect(16,232,448,52,6,v.stable?0x43af:0x322b);
  label(33,250,rest?"CAPTURE PLAYING POSITION":"CAPTURE RAISED POSITION");
}
void play(const View& v){
  if(cachedSite!=v.game.site||!background){
    landscape(v.game.site);cachedSite=v.game.site;
    if(background)memcpy(background,screen.getFramebuffer(),480*320*2);
  }else memcpy(screen.getFramebuffer(),background,480*320*2);
  const auto& g=v.game;top(v);
  int bobX=312+int(7*std::sin(v.time*.0015f));
  int bobY=184+int(2*std::sin(v.time*.005f));
  if(g.phase==Phase::Flight){float t=creek::limit(g.age/650.f,0,1);bobX=100+int(212*t);bobY=106+int(78*t-216*t*(1-t));}
  if(g.phase==Phase::Fight){bobX=130+int(178*creek::limit(g.line/g.target,0,1));bobY=198+int(6*std::sin(v.time*.012f));}
  if(g.phase==Phase::Bite)bobY+=12;else if(g.teasing())bobY+=4;
  int tip=v.raised?64:108;
  screen.drawLine(12,246,73,tip+18,ink);screen.drawLine(13,246,74,tip+18,ink);screen.drawLine(73,tip+18,103,tip,ink);
  if(g.running()){
    screen.drawLine(103,tip,bobX,bobY,0x73ee);
    screen.fillRect(bobX-3,bobY-6,7,5,gold);screen.fillRect(bobX-3,bobY-1,7,3,white);
    screen.drawFastHLine(bobX-11,bobY+4,23,paper);
  }
  const char* head="Raise the rod";const char* sub="Then sweep forward to your playing position.";
  char desc[64];int col=white;
  switch(g.phase){
  case Phase::Ready:if(v.raised)head="Cast forward";if(v.practice){head="Tap to cast";sub="Touch practice uses the lower panel.";}break;
  case Phase::Flight:head="Casting";sub="Let the float settle.";break;
  case Phase::Waiting:head="Watch the float";sub="Wait for it to go under.";break;
  case Phase::Bite:
    if(v.sound.cue!=2){head=v.practice?"BITE!  Tap to hook":"BITE!  Lift now";sub="";col=gold;screen.drawRoundRect(bobX-18,bobY-16,36,32,7,gold);}
    else {head="Watch the float";sub="Listen for the two-note bite.";}break;
  case Phase::Fight:
    fish(bobX-68,bobY+3,2,g.fish);
    head=g.surge()?"Fish running - ease off":"Reel it in";col=g.surge()?gold:white;
    snprintf(desc,sizeof(desc),"%.1f turns left  |  %s",g.line,v.practice?"Tap for 1/4 turn":"Watch line tension");sub=desc;
    screen.fillRect(284,250,170,8,green);screen.fillRect(284,250,int(170*g.heat),8,red);break;
  case Phase::Landed:{
    const auto& f=creek::catalog[g.fish];
    snprintf(desc,sizeof(desc),"%s  %d cm",f.name,g.length);head=desc;col=gold;
    sub=g.pointsAwarded?"Discovery reward: 1 tackle point!":g.newEntry?"New field book entry!":g.personalBest?"New personal best!":"Catch added to your field book.";
    screen.fillRoundRect(93,88,294,134,7,ink);label(110,100,creek::ranks[f.tier],gold);
    fish(144,116,4,g.fish);break;}
  case Phase::Lost:
    head=g.reason==creek::Reason::Early?"Hook set too early":g.reason==creek::Reason::Late?"The bite passed":g.reason==creek::Reason::Snapped?"The line snapped":"The fish slipped away";
    sub=v.practice?"Tap to cast again.":"Raise and cast again.";break;
  }
  if(!v.practice && (!v.motion || v.field!=Field::Good)){
    head=!v.motion?"Check the motion sensor":wheelFault(v.field);sub="Paused. Options offers touch practice.";col=gold;
  }
  screen.fillRect(0,264,480,56,ink);label(12,271,head,col);label(12,298,sub,green,1);
}
}
void beginScene(){
  if(!screenOK)return;
  background=(uint16_t*)ps_malloc(480*320*2);

}
namespace {
using namespace creek;
void bar(const char* title){
 screen.fillScreen(ink);label(12,11,title,paper);label(400,11,"BACK",gold);screen.drawFastHLine(10,36,460,green);
}
void row(int y,const char* title,const char* value){
 label(14,y,title,white);label(278,y,value,gold);screen.drawFastHLine(12,y+22,452,0x428c);
}
void hub(const View& v){
 bar("THAI WATERS");
 const char* a[]={"Fishing waters","Field book","Journey + tackle","Bench test","Sound + controls","Touch practice"};
 const char* b[]={sites[v.game.site].water,"Collection",chapters[v.game.progress.chapter()],"Live readings","Settings",v.practice?"On":"Off"};
 for(int i=0;i<6;i++)row(53+i*41,a[i],b[i]);
}
void waters(const View& v){
 bar("CHOOSE A WATER");
 for(int i=0;i<4;i++){
   int y=51+62*i;label(17,y,sites[i].name,i==v.game.site?gold:white);label(302,y,sites[i].water,green);
   label(17,y+23,sites[i].track,green,1);
 }
 label(15,304,"Travelling starts a fresh cast. Your book travels with you.",paper,1);
}
void book(const View& v){
 const auto& book=v.game.progress.book;int start=v.bookPage*5;char buf[64];
 bar("FIELD BOOK");snprintf(buf,sizeof(buf),"%s   %d/40 found",sites[start/10].name,book.discovered());label(14,47,buf,gold);
 for(int i=0;i<5;i++){
   int id=start+i;const auto& e=book.entries[id];int y=79+39*i;
   label(14,y,catalog[id].name,e.count?white:green);snprintf(buf,sizeof(buf),"%s | %lu caught | best %u cm",ranks[catalog[id].tier],(unsigned long)e.count,(unsigned)e.best);
   label(14,y+18,e.count?buf:ranks[catalog[id].tier],paper,1);
 }
 label(16,287,"< PREV",gold);snprintf(buf,sizeof(buf),"%d / 8",v.bookPage+1);label(205,287,buf);label(372,287,"NEXT >",gold);
}
void journey(const View& v){
 const auto& p=v.game.progress;char buf[72];bar("JOURNEY + TACKLE");
 snprintf(buf,sizeof(buf),"%s  |  %d points",chapters[p.chapter()],p.points());label(14,49,buf,gold);
 label(14,71,letters[p.chapter()],paper,1);label(14,85,story[p.chapter()],white,1);
 const char* units[]={"+150 ms per rank","+12% retrieval per rank","-10% tension gain per rank"};
 for(int i=0;i<3;i++){
   int y=104+48*i;label(16,y,paths[i]);snprintf(buf,sizeof(buf),"Rank %d/3",p.rank[i]);label(293,y,buf,green);
   snprintf(buf,sizeof(buf),"%s   /   next cost %d",units[i],p.rank[i]+1);label(16,y+20,p.rank[i]==3?"Maximum rank":buf,paper,1);
 }
 label(14,262,v.refundConfirm?"TAP TO CONFIRM REFUND":"Refund tackle points",gold);
 label(14,298,v.notice,green,1);
}
void bench(const View& v){
 bar("BENCH TEST");char b[90];
 snprintf(b,sizeof(b),"Tilt %+.1f deg   lift %.1f / low %.1f",v.degrees,v.span*.70,v.span*.27);
 label(12,46,v.calibrated&&v.motion?b:v.motion?"Calibrate two poses for degrees":"IMU unavailable",paper);
 snprintf(b,sizeof(b),"Casts %lu   Lifts %lu",(unsigned long)v.casts,(unsigned long)v.lifts);label(12,76,b);
 snprintf(b,sizeof(b),"%s | acceleration %.2f g",v.benchEvent,v.accelG);label(12,99,b,green,1);
 snprintf(b,sizeof(b),"Raw %d   %+.2f turns",v.raw,v.turns);label(12,123,v.field==Field::Good?b:wheelFault(v.field),gold);
 label(12,148,v.field!=Field::Good?"Reel paused":v.direction>0?"Winding IN":v.direction<0?"Paying OUT":"Turn the knob",white);
 label(12,175,v.sound.reverse?"Reverse direction: ON":"Reverse direction: OFF",green);
 snprintf(b,sizeof(b),"Cue level %d/3",v.sound.cueVolume);label(12,209,b,gold);label(251,209,"PLAY BITE",white);
 snprintf(b,sizeof(b),"Rumble %d/3",v.rumble);label(12,246,b,gold);label(177,246,"Tease",white);label(286,246,"Bite",white);label(387,246,"Pull",white);
 label(12,279,v.driver?"DRV2605L detected":"No DRV2605L detected",green,1);
 label(12,301,v.audio?"Tap a level to cycle. Tap direction to reverse.":"Audio unavailable - inspect codec / speaker.",paper,1);
}
}
void paint(const View& v){
 if(!screenOK)return;
 switch(v.page){
 case Page::Play:play(v);break;case Page::Hub:hub(v);break;case Page::Waters:waters(v);break;
 case Page::Book:book(v);break;case Page::Journey:journey(v);break;case Page::Bench:bench(v);break;
 case Page::Options:options(v);break;default:calibration(v);break;
 }
 if(v.saveFailed){screen.fillRect(0,302,480,18,ink);label(12,305,"Journal save failed - keep power on and check storage.",red,1);}
 screen.flush();
}

