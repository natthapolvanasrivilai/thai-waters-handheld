#pragma once
#include <cstdint>
namespace creek {
constexpr int siteCount=4, fishCount=40, perSite=10;
struct Site {const char *name,*track,*water;};
constexpr Site sites[]={
{"Chiang Mai Pond","Lotus at Dawn","Pond"},
{"Chao Phraya","Ferry Lanterns","River"},
{"Cheow Lan Lake","Karst Echo","Lake"},
{"Nong Khai Mekong","Mekong Afterglow","River"},
};
constexpr const char* ranks[]={"Common","Uncommon","Rare","Epic","Legendary"};
struct Species {const char* name; uint8_t low,high,tier,weight,form;};
constexpr Species catalog[]={
{"Climbing perch",9,23,0,16,0},
{"Three-spot gourami",8,16,0,16,0},
{"Silver barb",15,35,0,16,0},
{"Walking catfish",19,41,1,7,2},
{"Snakeskin gourami",13,25,1,7,0},
{"Nile tilapia",18,43,1,7,0},
{"Striped snakehead",25,66,2,3,1},
{"Broadhead catfish",20,38,2,3,2},
{"Marbled goby",21,50,3,2,1},
{"Giant gourami",37,68,4,1,0},
{"Redtail botia",12,24,0,16,0},
{"Tinfoil barb",14,34,0,16,0},
{"Banded mystus",9,22,0,16,2},
{"Siamese mud carp",18,47,1,7,0},
{"Red-tailed tinfoil barb",18,33,1,7,0},
{"Asian redtail catfish",28,84,1,7,2},
{"Soldier river barb",24,62,2,3,0},
{"Bronze featherback",22,53,2,3,1},
{"Clown featherback",39,91,3,2,1},
{"Giant barb",65,165,4,1,0},
{"Hampala barb",18,63,0,16,0},
{"Striped barb",7,16,0,16,0},
{"Forest snakehead",17,36,0,16,1},
{"Bonylip barb",14,35,1,7,0},
{"Spotted barb",9,19,1,7,0},
{"Red-tailed rasbora",8,17,1,7,1},
{"Great snakehead",39,88,2,3,1},
{"Blue mahseer",26,72,2,3,0},
{"Giant snakehead",40,105,3,2,1},
{"Thai mahseer",42,95,4,1,0},
{"Siamese glassfish",5,11,0,16,0},
{"Asian bumblebee catfish",7,15,0,16,2},
{"Yellow mystus",10,24,0,16,2},
{"Black sharkminnow",21,73,1,7,0},
{"Smallscale mud carp",15,34,1,7,0},
{"Siamese algae eater",8,16,1,7,1},
{"Striped river catfish",36,95,2,3,2},
{"Wallago catfish",57,145,2,3,2},
{"Jullien mud carp",45,110,3,2,0},
{"Mekong giant catfish",90,225,4,1,2},
};
struct Entry {uint32_t count=0; uint16_t best=0; uint16_t reserved=0;};
struct Journal {
 Entry entries[fishCount]{};
 int discovered(int start=0,int end=fishCount) const {int n=0;for(int i=start;i<end;i++)n+=entries[i].count>0;return n;}
 void record(int id,int cm){auto& e=entries[id];if(e.count!=UINT32_MAX)++e.count;if(cm>e.best)e.best=cm;}
};

constexpr const char* paths[]={"Hook timing","Reel gearing","Line control"};
constexpr const char* chapters[]={"First light","First entry","Reading water","Across the map","Master angler","Atlas complete"};
constexpr const char* story[]={"Land your first fish.","Find five species.","Visit two waters and log twelve species.","Log fish in all four waters and find 26 species.","Complete the 40-species field book.","Your atlas is complete. Chase personal bests."};
constexpr const char* letters[]={"At the lotus pond, a boatkeeper gives you an empty atlas.","Your first sketch earns a place in the ferry log.","The ferryman asks for a page from a second water.","Carry the lake sketches north to the Mekong landing.","Four landings have signed your book. Fill the missing pages.","The boatkeeper binds your atlas for the next traveller."};
struct Progress {
 Journal book;
 uint8_t rank[3]{}, reserved=0;
 int waters() const {int n=0;for(int i=0;i<siteCount;i++)n+=book.discovered(i*perSite,(i+1)*perSite)>0;return n;}
 int chapter() const {
   int n=book.discovered();if(n==40)return 5;if(n>=26 && waters()==4)return 4;
   if(n>=12 && waters()>=2)return 3;if(n>=5)return 2;return n?1:0;
 }
 int points() const {
   int n=book.discovered(),p=n?1+(n-1)/3:0;
   for(int v:rank)p-=v*(v+1)/2;return p;
 }
 bool upgrade(int i){
   if(i<0||i>2||rank[i]>=3||rank[i]>=chapter()||points()<rank[i]+1)return false;
   ++rank[i];return true;
 }
 void retrain(){for(auto& v:rank)v=0;}
};
}

