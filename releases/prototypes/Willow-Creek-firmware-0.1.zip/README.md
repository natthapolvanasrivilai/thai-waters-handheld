# Willow Creek · Prototype 0.1

Play on the Waveshare ESP32-S3-Touch-LCD-3.5B (31137) with the Rev E right-side AS5600 reel. You can also play on the bare display in touch practice mode. This release contains the compiled ESP32-S3 image, source, the four board libraries used by the build, and host tests.

## Play on USB

1. Use a USB data cable. The first bench run can use USB power alone. Plug the kit speaker into J9. For motion-and-knob play, connect A2 to J8 using the project wiring diagram (3V3 to VIN, common GND, GPIO8 to SDA, GPIO7 to SCL). Set the magnet on the reel axis.
2. Extract the ZIP and close any serial monitor connected to the board. From the extracted folder, install Espressif's flashing utility if needed and substitute the actual port for COM7. Flashing replaces the active factory firmware.

   ~~~powershell
   python -m pip install esptool==5.3.0
   .\Flash-Willow.ps1 -Port COM7
   ~~~

   Alternatively, run this command from the extracted folder on any supported OS. Substitute the USB port, such as /dev/ttyACM0 on Linux.

   ~~~sh
   python -m esptool --chip esp32s3 --port COM7 write-flash --flash-mode dio --flash-freq 80m --flash-size 16MB 0x0 flash/bootloader.bin 0x8000 flash/partitions.bin 0xe000 flash/boot_app0.bin 0x10000 flash/WillowCreek.bin
   ~~~

   If USB download mode is needed, hold BOOT, press and release RESET, then release BOOT. Reset once after writing if the board stays in download mode. Boot diagnostics on the 115200 serial monitor report LCD, IMU, codec/audio and charger-register readback.
3. Hold your normal playing pose steady and tap **Capture playing position**. Tilt the handheld as if lifting a rod, about 30–50°, hold still and tap **Capture raised position**. The two poses define the lift direction. Calibration is saved on the board.
4. **Cast** by raising the rod, then sweeping forward to the playing position. Keep the rod down as the float settles. **Hook** by lifting when the float dips. The hook window lasts 1.45 seconds. **Retrieve** with the knob. Ease off when the fish runs and the tension bar fills, then wind steadily to land it. Lower the rod after landing and raise and cast again. If winding pays out line, change **Options → Reel direction**.
5. With the case or knob still on the bench, open **Options → Controls** and select **Touch practice**. Tap the bottom panel to cast, tap on the bite to hook, then tap for quarter-turns. Returning to motion controls starts a fresh cast. The control mode resets to motion at boot.

## Sound

**Options** pauses the fishing clock. Tap a row to cycle its value. **Adaptive** plays the original 24-second *Willow After Rain* score with a rhythmic layer during the fight. **Drift** plays bass and water notes, **Melody** includes the lead, and **Off** silences the music. Music and bite tones each have four volume settings. Choose **Light + tone**, **Light**, or **Tone** for the bite alert. The float always dips. Cue settings preview the two-note sound when enabled. Sound settings, winding direction and rod calibration persist through power cycles. The landed count is for the current session.

## Build from source

Use Arduino CLI 1.3.1, Espressif core 3.3.10 and the bundled libraries from Waveshare commit **c7dd63c70258da7e3b6dae0c621f30ca62b1e1c9**. The game targets the **3.5B** using the vendor's 16 MB flash, 8 MB OPI PSRAM, hardware CDC profile. From the extracted folder run:

~~~sh
arduino-cli core update-index --additional-urls https://espressif.github.io/arduino-esp32/package_esp32_index.json
arduino-cli core install esp32:esp32@3.3.10 --additional-urls https://espressif.github.io/arduino-esp32/package_esp32_index.json
arduino-cli compile --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,PartitionScheme=app3M_fat9M_16MB,USBMode=hwcdc,CDCOnBoot=cdc" --libraries libraries WillowCreek
~~~

The board option selects QIO. The generated upload arguments specify DIO for the boot image. Creek.h contains the game, gesture and angle processing. Synth.h and Score.h supply the 16 kHz music and bite signal. The renderer uses the original pixel landscape in Landscape.h.

## Verification and first-board observations

- The target build succeeded. Espressif's image reader identified the application as ESP32-S3. Each flash segment matched the corresponding bytes in Arduino's merged image.
- Host replay exercised encoder wrap, reversal, invalid-field recovery, missed strikes, line breakage, and 99 seeded catches. Host audio tests exercised mute, cue timing, arrangements, stereo output and the loop boundary. The desktop practice build uses these same C++ game and synth sources compiled to WebAssembly. Its cast-to-catch flow and settings controls passed a browser test.
- Compile tests/replay.cpp and tests/audio.cpp separately as C++17 executables to rerun the tests, with assertions enabled. Captured results and binary hashes are in verification/.
- No physical board or reel was connected. On the first run confirm both calibration buttons register in landscape, winding advances the line in the selected direction, and both bite tones are audible. A weak, strong or missing magnet pauses motion play and displays the fault. If the magnet status is good but the line moves erratically, check sensor centering through one complete loaded turn.
- The firmware requests the project's 4.20 V / 300 mA settings and reads both PMIC registers back. Boot readback confirms configuration only. The Rev E fit print, actual charging current, runtime, physical gesture feel and speaker level still need bench observation.

The board profile and peripheral integrations follow Waveshare's board examples. [Pinned Waveshare source](https://github.com/waveshareteam/ESP32-S3-Touch-LCD-3.5B/tree/c7dd63c70258da7e3b6dae0c621f30ca62b1e1c9) · [Hardware documentation](https://docs.waveshare.com/ESP32-S3-Touch-LCD-3.5B)
