#include "Scene.h"
#include "Landscape.h"
#include <cstdio>
#include <cstring>
using creek::Phase;
namespace {
constexpr int ink=0x19e7,paper=0xe70f,white=0xff9b,gold=0xf50c,green=0x94f2,red=0xf386;
uint16_t* background=nullptr;
void landscape(){
  for(int y=0;y<160;y++)for(int x=0;x<240;x++){
    int b=creekPixels[y*120+x/2];
    screen.fillRect(x*2,y*2,2,2,creekColors[(x&1)?b&15:b>>4]);
  }
}
void label(int x,int y,const char* s,int col=white,int size=2){
  screen.setTextSize(size);screen.setTextColor(col);screen.setCursor(x,y);screen.print(s);
}
void fish(int x,int y,int k,int kind){
  const char* sprite[]={"       XX     ","     XXXXX    ","X  XXXXXXXXX  ","XXXXXXXXXXXXXX","X  XXXXXXXXXX ","     XX X     ","        X     "};
  const int scales[]={0xa548,0xa5b0,0xcded};
  for(int row=0;row<7;row++)for(int j=0;sprite[row][j];j++)if(sprite[row][j]=='X'){
    int c=(row==2 && j==10)?ink:row==4?paper:scales[kind];
    screen.fillRect(x+j*k,y+row*k,k,k,c);
  }
  for(int j=5;j<=9;j+=2)screen.fillRect(x+j*k,y+3*k,k,k,ink);
}
const char* wheelFault(Field f){
  switch(f){case Field::Weak:return "Magnet too weak";case Field::Strong:return "Magnet too strong";
  case Field::NoMagnet:return "Center magnet over reel sensor";default:return "Connect AS5600 reel to J8";}
}
void top(const View& v){
  screen.fillRect(0,0,480,33,ink);label(10,9,"WILLOW CREEK",paper);
  char t[36];snprintf(t,sizeof(t),"%s  %d",v.practice?"PRACTICE":"CATCH",v.game.catches);
  label(195,9,t,green);label(382,9,"OPTIONS",white);
}
void options(const View& v){
  const char* music[]={"Adaptive","Drift","Melody","Off"};
  const char* volume[]={"Off","Low","Medium","High"};
  const char* cues[]={"Light + tone","Light","Tone"};
  const char* rows[]={"Music","Music volume","Bite cue","Cue volume","Reel direction","Controls","Rod calibration"};
  const char* vals[]={music[v.sound.music],volume[v.sound.volume],cues[v.sound.cue],volume[v.sound.cueVolume],
    v.sound.reverse?"Reversed":"Forward",v.practice?"Touch practice":"Motion + knob","Set two poses"};
  screen.fillScreen(ink);label(14,12,"CREEK OPTIONS",paper);label(397,12,"DONE",gold);
  for(int i=0;i<7;i++){
    int y=42+37*i;screen.drawFastHLine(14,y,450,0x428c);label(15,y+10,rows[i],white);label(258,y+10,vals[i],green);
  }
  label(14,305,v.audio?"Tap a row to change it.":"Audio unavailable - check codec.",gold,1);
}
void calibration(const View& v){
  bool rest=v.page==Page::Rest;
  screen.fillScreen(ink);label(18,17,"ROD CALIBRATION",green);label(380,17,"OPTIONS",white);
  label(18,74,rest?"1  Playing position":"2  Raised rod",paper,3);
  label(18,137,rest?"Hold the screen as you play.":"Lift the far edge 30-50 degrees.");
  label(18,172,v.badPose?"Try a larger, steady lift.":!v.motion?"IMU unavailable. Try practice.":v.stable?"Steady. Tap to capture.":"Hold still for half a second.",gold);
  screen.fillRoundRect(16,232,448,52,6,v.stable?0x43af:0x322b);
  label(33,250,rest?"CAPTURE PLAYING POSITION":"CAPTURE RAISED POSITION");
}
void play(const View& v){
  if(background)memcpy(screen.getFramebuffer(),background,480*320*2);else landscape();
  const auto& g=v.game;top(v);
  int bobX=312+int(7*std::sin(v.time*.0015f));
  int bobY=184+int(2*std::sin(v.time*.005f));
  if(g.phase==Phase::Flight){float t=creek::limit(g.age/650.f,0,1);bobX=100+int(212*t);bobY=106+int(78*t-216*t*(1-t));}
  if(g.phase==Phase::Fight){bobX=130+int(178*creek::limit(g.line/g.target,0,1));bobY=198+int(6*std::sin(v.time*.012f));}
  if(g.phase==Phase::Bite)bobY+=12;
  int tip=v.raised?64:108;
  screen.drawLine(12,246,73,tip+18,ink);screen.drawLine(13,246,74,tip+18,ink);screen.drawLine(73,tip+18,103,tip,ink);
  if(g.running()){
    screen.drawLine(103,tip,bobX,bobY,0x73ee);
    screen.fillRect(bobX-3,bobY-6,7,5,gold);screen.fillRect(bobX-3,bobY-1,7,3,white);
    screen.drawFastHLine(bobX-11,bobY+4,23,paper);
  }
  const char* head="Raise the rod";const char* sub="Then sweep forward to your playing position.";
  char desc[64];int col=white;
  switch(g.phase){
  case Phase::Ready:if(v.raised)head="Cast forward";if(v.practice){head="Tap to cast";sub="Touch practice uses the lower panel.";}break;
  case Phase::Flight:head="Casting";sub="Let the float settle.";break;
  case Phase::Waiting:head="Watch the float";sub="Wait for it to go under.";break;
  case Phase::Bite:
    if(v.sound.cue!=2){head=v.practice?"BITE!  Tap to hook":"BITE!  Lift now";sub="";col=gold;screen.drawRoundRect(bobX-18,bobY-16,36,32,7,gold);}
    else {head="Watch the float";sub="Listen for the two-note bite.";}break;
  case Phase::Fight:
    head=g.surge()?"Fish running - ease off":"Reel it in";col=g.surge()?gold:white;
    snprintf(desc,sizeof(desc),"%.1f turns left  |  %s",g.line,v.practice?"Tap for 1/4 turn":"Watch line tension");sub=desc;
    screen.fillRect(284,250,170,8,green);screen.fillRect(284,250,int(170*g.heat),8,red);break;
  case Phase::Landed:{
    const char* names[]={"Brook trout","Creek chub","Brown trout"};
    snprintf(desc,sizeof(desc),"%s  /  %d cm",names[g.fish],g.length);head=desc;col=gold;
    sub=v.practice?"Landed! Tap for another cast.":"Landed! Raise and cast again.";fish(200,115,6,g.fish);break;}
  case Phase::Lost:
    head=g.reason==creek::Reason::Early?"Hook set too early":g.reason==creek::Reason::Late?"The bite passed":g.reason==creek::Reason::Snapped?"The line snapped":"The fish slipped away";
    sub=v.practice?"Tap to cast again.":"Raise and cast again.";break;
  }
  if(!v.practice && (!v.motion || v.field!=Field::Good)){
    head=!v.motion?"Check the motion sensor":wheelFault(v.field);sub="Paused. Options offers touch practice.";col=gold;
  }
  screen.fillRect(0,264,480,56,ink);label(12,271,head,col);label(12,298,sub,green,1);
}
}
void beginScene(){
  if(!screenOK)return;
  landscape();background=(uint16_t*)ps_malloc(480*320*2);
  if(background)memcpy(background,screen.getFramebuffer(),480*320*2);
}
void paint(const View& v){
  if(!screenOK)return;
  if(v.page==Page::Options)options(v);
  else if(v.page==Page::Play)play(v);
  else calibration(v);
  screen.flush();
}
