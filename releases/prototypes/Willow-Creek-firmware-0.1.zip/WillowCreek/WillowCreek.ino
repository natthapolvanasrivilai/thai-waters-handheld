#include "Scene.h"
#include <Preferences.h>
#include <esp_system.h>

using namespace creek;
namespace {
View view;
Preferences store;
Calibration setupPose{};
Gesture rod;
Wheel wheel;
Vec filtered{},lastStable{};
bool hasFilter=false,held=false;
uint32_t steadySince=0,lastTick=0,lastDraw=0,lastTouch=0,lastDown=0;
bool everDrawn=false;
Page returnTo=Page::Play;

void restore(){
  store.begin("willow-v1",false);
  if(store.getBytesLength("poses")==sizeof(Calibration))store.getBytes("poses",&setupPose,sizeof(setupPose));
  view.calibrated=setupPose.valid();
  view.page=view.calibrated?Page::Play:Page::Rest;
  view.sound.music=store.getUChar("music",0);view.sound.volume=store.getUChar("volume",2);
  view.sound.cue=store.getUChar("cue",0);view.sound.cueVolume=store.getUChar("cuevol",2);
  view.sound.reverse=store.getBool("reverse",false);
  if(!view.sound.valid())view.sound=SoundSettings{};
}
void playPage(){
  view.page=(view.practice||view.calibrated)?Page::Play:Page::Rest;
  rod=Gesture{};wheel.previous=-1;
}
void change(int x,int y,bool& practiceTap){
  if(view.page!=Page::Options && y<40 && x>=365){
    returnTo=view.page;view.page=Page::Options;rod=Gesture{};return;
  }
  if(view.page==Page::Options){
    if(y<40 && x>=365){view.page=returnTo;if(view.page==Page::Play)playPage();return;}
    if(y<42 || y>=301)return;
    bool preview=false;
    switch((y-42)/37){
    case 0:view.sound.music=(view.sound.music+1)%4;store.putUChar("music",view.sound.music);break;
    case 1:view.sound.volume=(view.sound.volume+1)%4;store.putUChar("volume",view.sound.volume);break;
    case 2:view.sound.cue=(view.sound.cue+1)%3;store.putUChar("cue",view.sound.cue);preview=true;break;
    case 3:view.sound.cueVolume=(view.sound.cueVolume+1)%4;store.putUChar("cuevol",view.sound.cueVolume);preview=true;break;
    case 4:view.sound.reverse=!view.sound.reverse;store.putBool("reverse",view.sound.reverse);wheel.previous=-1;break;
    case 5:view.practice=!view.practice;view.game.enter(Phase::Ready);playPage();return;
    case 6:view.practice=false;view.page=Page::Rest;view.badPose=false;rod=Gesture{};return;
    }
    setSound(view.sound,false,preview);return;
  }
  if(view.page==Page::Rest||view.page==Page::Raise){
    if(y<222 || y>293 || !view.stable)return;
    if(view.page==Page::Rest){lastStable=unit(filtered);view.page=Page::Raise;view.badPose=false;}
    else {
      Calibration trial{lastStable,unit(filtered)};
      if(!trial.valid()){view.badPose=true;return;}
      setupPose=trial;store.putBytes("poses",&setupPose,sizeof(setupPose));view.calibrated=true;
      view.game.enter(Phase::Ready);playPage();
    }
    return;
  }
  if(view.practice && y>=245)practiceTap=true;
}
void sampleRod(uint32_t now,uint32_t dt){
  Vec raw{};view.motion=acceleration(raw);
  if(!view.motion){hasFilter=false;view.stable=false;steadySince=now;rod=Gesture{};return;}
  float len=dot(raw,raw);
  if(len<.67f || len>1.43f){
    view.stable=false;steadySince=now;rod.cast=rod.rise=false;return;
  }
  raw=unit(raw);
  if(!hasFilter){filtered=raw;steadySince=now;hasFilter=true;}
  if(dot(raw,filtered)<.9975f)steadySince=now;
  float alpha=limit(dt/(55.f+dt),0,1);
  filtered=unit({filtered.x+alpha*(raw.x-filtered.x),filtered.y+alpha*(raw.y-filtered.y),filtered.z+alpha*(raw.z-filtered.z)});
  view.stable=now-steadySince>=420;
  if(view.page==Page::Play && !view.practice && view.calibrated){
    rod.sample(setupPose.tilt(filtered),setupPose.span(),now);view.raised=rod.high;
  } else {rod=Gesture{};view.raised=false;}
}
}
void setup(){
  Serial.begin(115200);restore();view.game.seed=esp_random();beginBoard();beginScene();
  view.audio=startSound();setSound(view.sound,false,false);
  Serial.printf("Willow Creek 0.1 | LCD %d IMU %d audio %d charge config 4.20V/300mA readback %d\n",screenOK,imuOK,view.audio,powerOK);
  lastTick=millis();paint(view);
}
void loop(){
  uint32_t now=millis(),dt=now-lastTick;
  if(dt<12){delay(1);return;}
  lastTick=now;dt=std::min<uint32_t>(dt,100);view.time=now;
  sampleRod(now,dt);
  int angle=0;view.field=readWheel(angle);
  float turns=wheel.read(angle,view.field==Field::Good,now,view.sound.reverse);
  bool tap=false;
  if(now-lastTouch>=24){
    lastTouch=now;int x,y;bool down=touchPoint(x,y);
    if(down){lastDown=now;if(!held)change(x,y,tap);held=true;}
    else if(now-lastDown>=45)held=false;
  }
  Phase before=view.game.phase;
  if(view.page==Page::Play && (view.practice||(view.motion&&view.field==Field::Good))){
    view.game.tick(dt,view.practice?tap:rod.cast,view.practice?tap:rod.rise,view.practice?(tap?.25f:0):turns);
  } else if(view.page==Page::Play)rod=Gesture{};
  if(view.game.phase!=before){
    Serial.printf("phase=%u catch=%d line=%.2f\n",unsigned(view.game.phase),view.game.catches,view.game.line);
  }
  setSound(view.sound,view.page==Page::Play && view.game.phase==Phase::Fight,view.game.phase!=before&&view.game.phase==Phase::Bite);
  if(!everDrawn||now-lastDraw>=55){lastDraw=now;everDrawn=true;paint(view);}
}

