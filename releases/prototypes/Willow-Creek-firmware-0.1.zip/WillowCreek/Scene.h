#pragma once
#include "Board.h"
#include "Sound.h"
enum class Page { Play, Options, Rest, Raise };
struct View {
  creek::Game game;
  SoundSettings sound;
  Page page=Page::Rest;
  Field field=Field::Missing;
  bool practice=false, audio=false, motion=false, stable=false, badPose=false, raised=false, calibrated=false;
  uint32_t time=0;
};
void beginScene();
void paint(const View& v);
