param([Parameter(Mandatory=$true)][string]$Port)
$ErrorActionPreference='Stop'
$images=Join-Path $PSScriptRoot 'flash'
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'verification/sha256.json') -Raw | ConvertFrom-Json
foreach($entry in $manifest.psobject.Properties) {
    $actual=(Get-FileHash -LiteralPath (Join-Path $images $entry.Name) -Algorithm SHA256).Hash
    if($actual -ne $entry.Value){throw "Image checksum mismatch for $($entry.Name)"}
}
python -m esptool --chip esp32s3 --port $Port write-flash --flash-mode dio --flash-freq 80m --flash-size 16MB 0x0 "$images/bootloader.bin" 0x8000 "$images/partitions.bin" 0xe000 "$images/boot_app0.bin" 0x10000 "$images/ThaiWaters.bin"
exit $LASTEXITCODE
