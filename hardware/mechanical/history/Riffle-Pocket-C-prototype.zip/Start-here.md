# Riffle Pocket C

## Build status

One-unit engineering prototype. The rear reel folds into the body and the front accepts Waveshare's bare ESP32-S3-Touch-LCD-3.5B, SKU 31137. The active region is 73.44 x 48.96 mm, roughly 52% of the 100 x 69 mm rectangular face. The stowed case is 30 mm thick. The 10 mm plan-view corner radius and 4.5 mm front/back edge radii extend around the housing. Four recessed board screws and rear sound slots leave the perimeter smooth.

The folder includes two STEP assemblies in the carry and fishing positions, six printable STLs in millimeters, the parametric source, a mechanical check summary, the editable cost and power workbook and a note-event score for the original soundtrack. The consumer-facing preview shows an illustrative game screen. Gameplay firmware is a later build.

## Folding reel

Hook a fingertip into the scallop in the rotor, lift the free-spinning grip 90 degrees, and turn the rear-right wheel. The grip revolves about its own stem as the wheel turns. Fold it back toward the center at any wheel angle. A friction hinge controls opening and closing, and the molded heel arrests opening overtravel. There is no latch to operate. The grip is about 1.2 mm behind the back plane when folded. Overall thickness increases to 45.35 mm with it open.

A 6 mm diametrically magnetized disk in the wheel shaft rotates past a fixed AS5600 sensor inside the case. This gives direction, speed and partial turns. The original one-pulse scheme would make a slow retrieve feel uneven. Use short, decelerating cranks to jig, a steady turn to swim the lure, and a pause to let the fish run.

### CAD verification and limits

- Solid intersection checks sampled opening in 5-degree steps and a full reel revolution in 10-degree steps. The round well also provides invariant radial clearance around the wheel. All six print exports passed watertight, single-solid mesh checks.
- Vendor geometry was transformed to landscape, and 546 solids from the manufacturer's STEP were checked against printed parts and component allowances. The compact STEP deliverables include simplified glass and board references. The source accepts the original vendor STEP for rebuilding and checking.
- The drawing gives 11.50 mm overall depth, whereas the downloaded 3D assembly spans 13.40 mm. Clearance uses the deeper model. Confirm the hardware revision on receipt.
- The battery body, speaker and sensor are modeled as packaging allowances. Confirm the speaker's actual outline, sensor connectors, battery lead bend, plug overmold and insulation on a physical dry fit. The CAD check excludes flexible wires, manufacturing tolerances and deformation.

### One-unit assembly

1. Print housing, bezel, rotor, folding stem, grip and collar. Start at 0.20 mm layers with a 0.4 mm nozzle and three perimeters. Review the recessed wheel well, board screw counterbores and the rotor in the slicer for locally removable support. The stem benefits from tough filament and a brim or a revised orientation if layer adhesion is poor. Clean the bearings and hinge holes.
2. Slip the grip over the stem. Install the small end washer and M2 x 5 screw. Seat the washer against the axle end. The grip must turn freely. Put one 0.25-0.30 mm nylon shim on each side of the stem at the hinge and fit the M2 x 10 pivot screw through the clearance cheek into the far pilot. Adjust until the handle stays stowed during a pocket draw and does not collapse under normal finger pressure. Excess torque can strip the printed cheek.
3. Bond the 6 x 2.5 mm magnet into the round shaft pocket, flush with the pocket seat as modeled. Insert the complete rotor from the back. Bond the loose collar to the shaft **inside the open housing** with a small drop on the shaft/collar interface. Keep adhesive away from the housing bearing. Set the collar with a temporary 0.3-0.4 mm shim against the housing, remove the shim after cure, and check rotation. A scrap test helps establish screw fit and adhesive compatibility for your material.
4. Place the AS5600 with its IC centered on the rear wheel axis and facing the magnet. Shim the breakout on its two pads to a nominal 1.2 mm chip-to-magnet face gap. Use the sensor's magnet-detect and field-strength diagnostics while turning through 360 degrees, then fix the breakout. Verify centering under side load. A 6 mm target is alignment-sensitive. Leave room for its I2C lead. For the first unit the solder pads allow lower-profile wiring than vertical headers.
5. Place the included speaker over the rear vents using a thin acoustic gasket. Locate the protected 1200 mAh cell between the rails. Route its leads up into the free cavity and provide strain relief. Use removable foam tape for the cell and avoid compressing it when the board is installed.
6. Power the board from USB first. Use the board-revision pinout to connect 3.3 V, ground, SDA and SCL to the angle breakout. Confirm the encoder, IMU, touch panel and codec individually. The protected Adafruit pack has a JST-PH plug. The Waveshare battery header is MX1.25. Check the keyed adapter and polarity at the board end with a meter before connecting the cell. Configure the AXP2101 for a 4.2 V single cell. A 300 mA initial charge setting is within this cell maker's 500 mA maximum. Check the actual programmed current and termination before enclosed charging.
7. Lower the board onto the four mounting posts with USB facing the left tunnel. Fasten from the rear with four M2 x 8 screws. Verify the received threaded standoff accepts about 2 mm engagement. Check USB data, power-button access and cable reach. Apply thin removable tape to the outer shell rim to hold the bezel. Keep adhesive off the active screen. Allow the lens its nominal 0.25 mm axial clearance.

### First physical checks

Test the bare reel for 100 opening cycles and ten pocket insertion/removal cycles in the clothes it will be carried in. Check for accidental opening, exposed fasteners, fabric snagging, contact with the opening lip, bearing play and any layer cracks. Those are first-unit screening targets. Check that an unfamiliar player can find the finger scoop and land a fish while supporting the screen. A successful fit check alone does not establish long-term wear.

## Gameplay for the first playable version

Start with one creek, three fish and two lures. Build one minute of fishing worth repeating before expanding the map.

| What the player sees or hears | Physical response | What they learn |
| --- | --- | --- |
| A tiny ripple and a single soft tick | Keep the rod steady | A nibble differs from a committed bite. |
| The float dips fully and a rising two-note cue sounds | Lift the device to set the hook | The first successful hook should feel intentional. |
| A trout darts, the line straightens and the reel tone rises | Pause the crank and lower the rod a little | Giving line preserves the hook. |
| The fish turns side-on and the line arc softens | Wind steadily while raising the rod | The player can recognize a recovery window. |
| A perch follows but turns away on a fast retrieve | Try a slow turn, pause, and twitch | An unsuccessful cast provides information for the next attempt. |

A creek chub teaches a steady retrieve. A perch rewards pauses. A trout teaches release-and-recover timing. On each field-journal page, record the water, lure, retrieve pattern and personal best. A lost fish can reveal a visible behavior clue. Unlock the next water by demonstrating two techniques. Keep free fishing, selectable conditions and optional skill challenges available after the journal fills. Save after a catch and allow immediate exit.

For a first playtest, give five first-time players the same creek. Observe whether they voluntarily cast again, distinguish a nibble from a bite and can describe why a fish escaped. Then replay a familiar fish with a different lure. Those observations guide tuning better than adding more species immediately.

## Sound

Willow After Rain is an original 16-bar, 24-second, mono 6/8 theme. The browser player has Creek melody, Quiet water, Fish on the line, Effects only and Silent arrangements, separate volume controls and a test-bite button. The quiet arrangement removes the lead. The fighting arrangement adds a quick pulse. The bite cue briefly lowers the backing music. Preferences persist when browser storage is available. The WAV is the standalone creek mix. The JSON score supplies note number, onset in seconds, duration, voice and level for each event.

For the game, trigger the fight layer from line tension, bring it down on slack, and leave occasional bars of water sounds between melody phrases. Give every essential audio cue a matching float or line animation so silent mode remains fully playable. Test sound levels on the enclosed speaker.

## Cost and runtime

The workbook uses one US retail reference per main component plus explicit allowances for commodity hardware and consumables. A supplier listing showed the board awaiting restock. Quantities are per completed prototype, and checkout totals depend on pack sizes, tax and delivery. No custom PCB is required for this revision.

The power sheet assumes a 1200 mAh cell, 85% usable capacity and whole-device battery current of 120, 180 or 270 mA. Expected play under those scenarios is 8.5, 5.7 or 3.8 hours respectively. These currents are design assumptions. Keep radios off during fishing and dim the backlight while paused. Replace the assumptions with measurements from the battery lead, USB disconnected, and confirm with a full charge-to-shutdown run in the chosen mode.

[Waveshare mechanical files and schematics](https://docs.waveshare.com/ESP32-S3-Touch-LCD-3.5B/Resources-And-Documents) | [AS5600 setup](https://learn.adafruit.com/adafruit-as5600-magnetic-angle-sensor?view=all) | [Battery specifications](https://www.adafruit.com/product/258)
