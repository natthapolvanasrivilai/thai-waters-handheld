"""Riffle Pocket D. Units in mm. Rebuild with CadQuery 2.8 + trimesh 5.
Usage: python pocket.py path/to/waveshare.stp output-folder
Manufacturer CAD: https://docs.waveshare.com/ESP32-S3-Touch-LCD-3.5B/Resources-And-Documents
"""
from pathlib import Path
import sys, math, json
import cadquery as cq, trimesh
from cadquery import Vector as V
dest=Path(sys.argv[2]);dest.mkdir(exist_ok=True,parents=True)
for sub in ['print','views']:(dest/sub).mkdir(exist_ok=True)
def box(x,y,z,w,d,h):return cq.Workplane('XY').box(w,d,h,centered=(True,True,False)).translate((x,y,z))
def rr(x,y,z,w,d,h,r):return box(x,y,z,w,d,h).edges('|Z').fillet(r)
def cyl(p,d,r,h):return cq.Workplane(obj=cq.Solid.makeCylinder(r,h,V(*p),V(*d)))
def cz(x,y,z,r,h):return cyl((x,y,z),(0,0,1),r,h)
def cx(x,y,z,r,h):return cyl((x,y,z),(1,0,0),r,h)
def cy(x,y,z,r,h):return cyl((x,y,z),(0,1,0),r,h)
def skin(x):return x.val()
W,D,H=108.5,69,30
RIGHT=58.5
AXIS_Z=14.8
def side(it):
    # Local +depth maps into the right wall. The spindle is parallel to world X.
    return it.rotate((0,0,0),(0,0,1),90).rotate((0,0,0),(0,1,0),-90).translate((RIGHT,0,AXIS_Z))
REEL=0; R=7.8; P=REEL+R; Z=4.9
outer=rr(4.25,0,0,W,D,H,10).edges('>Z or <Z').fillet(4.5)
base=outer.intersect(box(0,0,0,140,90,27.8)).cut(rr(4.25,0,2.5,W-4,65,28,8))
# Board bore and locating shelf are independent of the reel.
for x in [-36,36]:
    for y in [-24.25,24.25]:
        base=base.union(cz(x,y,2,3.25,15)).cut(cz(x,y,-1,1.15,20)).cut(cz(x,y,-1,2.3,12))
# The well opens on the right flank. Trim its outer wall to the case edge radius.
well=side(cz(0,0,0,14.7,11.5)).intersect(outer).intersect(box(0,0,0,140,90,27.8))
side_opening=side(cz(0,0,-2,13.35,11.85))
lead=cq.Workplane(obj=cq.Solid.makeCone(14.2,13.35,1.1,V(0,0,0),V(0,0,1)))
side_opening=side_opening.union(side(lead))
base=base.union(well).cut(side_opening).cut(side(cz(0,0,9,4.85,4)))
base=base.cut(box(-46,0,16,18,15.5,8.4).edges('|X').fillet(2.2))
base=base.cut(box(-17,-30.5,17.5,26,10,6).edges('|Y').fillet(1.7))
for y in [-6,-3,0,3,6]:base=base.cut(rr(-38,y,-1,9,1.25,5,.59))
# Cell lateral fences, plus open end for protected pack leads.
for x in [-29.8,6.8]:base=base.union(rr(x,0,2.1,1.8,47,2.8,.7))
# Small sensor carrier pads rise from the circular bearing housing.
for s in [-1,1]:base=base.union(side(box(s*9,0,10.8,3.1,9,5.1)))
lid=outer.intersect(box(0,0,27.8,140,90,4)).cut(side_opening).cut(rr(0,0,24.8,93.35,61.9,3.95,6.1))
lid=lid.cut(rr(0,0,28.6,76.8,52.2,3,1.6))
# Rotor with a recessed finger scoop and two hinge cheeks; solid heel stops the upright stem.
wheel=cz(REEL,0,1,12.75,8.5).edges('<Z').fillet(.9)
wheel=wheel.cut(rr(REEL-0.8,0,-1,22.9,9.6,9.85,2.1))
wheel=wheel.cut(cz(REEL-6.2,3.5,-1,4.9,7.3))
wheel=wheel.union(cz(REEL,0,9.2,4.55,5.7)).cut(cz(REEL,0,12.25,3.1,3.1))
for s in [-1,1]:
    cheek=box(P,s*3.8,2,5.8,2.35,6.4).edges('|Y').fillet(1.15)
    wheel=wheel.union(cheek)
wheel=wheel.cut(cy(P,-6,Z,1.1,8.8)).cut(cy(P,2.7,Z,.85,3.4))
wheel=wheel.cut(cy(P,-16,Z,1.95,11.2))
# Fixed heel leaves a clearance to the upright handle then arrests overtravel.
wheel=wheel.union(box(P+3.6,0,1.05,2.4,4.6,7.3))
# Hollow bearing peg with independent rotating orange sleeve and retained end washer.
stem=cy(P,-2.3,Z,2.23,4.6).union(cx(P-6,0,Z,2.1,6))
stem=stem.union(cx(P-16.05,0,Z,1.9,10.35)).cut(cx(P-16.25,0,Z,.80,5.4))
stem=stem.union(cx(P-6.15,0,Z,2.65,.9)).cut(cy(P,-3,Z,1.07,6))
knob=cx(P-15.75,0,Z,3.75,9.3).edges('>X or <X').fillet(1.15)
knob=knob.cut(cx(P-16.25,0,Z,2.14,13))
for i in range(12):
    a=2*math.pi*i/12
    knob=knob.cut(cx(P-16.75,4.05*math.cos(a),Z+4.05*math.sin(a),.52,14))
ret=cz(REEL,0,11.85,6.6,2.5).cut(cz(REEL,0,11.7,4.70,3))
# Retain the collar with adhesive applied only to shaft/collar interface.
pin=cy(P,-4.8,Z,.96,7.5).union(cy(P,2.7,Z,.80,2.5));phead=cy(P,-6.15,Z,1.7,1.35)
end=cx(P-18.0,0,Z,1.75,1.55).union(cx(P-16.45,0,Z,2.7,.4))
def fold(obj,a):
    return obj.rotate((RIGHT-Z,P,AXIS_Z),(RIGHT-Z,P,AXIS_Z-1),-a)
wheel,stem,knob,ret,pin,phead,end=[side(v) for v in [wheel,stem,knob,ret,pin,phead,end]]
def volume(v):return v.val().Volume()
parts={'housing':base,'bezel':lid,'rotor':wheel,'folding-stem':stem,'grip':knob,'collar':ret}
ref={'hinge screw':pin.union(phead),'grip retainer':end,'magnet':side(cz(0,0,12.25,3,2.5)),
     'battery':box(-11.5,0,3.6,34,62,5),'speaker allowance':rr(-38.65,0,3.2,15,30,7,1.4),
     'sensor chip allowance':side(box(0,0,15.95,5,5,1.4)),
     'sensor PCB allowance':side(box(0,0,17.35,25.4,17.8,1.6))}
# Sensor pads accept shim/tape to the underside of the breakout. Confirm header depth with wires fitted.
vendor=cq.importers.importStep(sys.argv[1]).rotate((0,0,0),(0,0,1),-90).translate((0,0,27.4))
board_solids=vendor.val().Solids()
bbox=lambda a:a.val().BoundingBox()
def overlaps(a,b):
    return all(getattr(a,k+'max')>getattr(b,k+'min')+.0001 and getattr(b,k+'max')>getattr(a,k+'min')+.0001 for k in 'xyz')
def clear(n,a,m,b):
    if overlaps(bbox(a),bbox(b)):
        v=volume(a.intersect(b))
        assert v<.002,(n,m,v)
def mesh(it,path):
    cq.exporters.export(it,str(path),tolerance=.04,angularTolerance=.1)
for deg in range(0,91,5):
    for n,v in [('stem',stem),('knob',knob),('grip screw',end)]:
        obj=fold(v,deg)
        for m,b in [('rotor',wheel),('housing',base),('bezel',lid)]:clear(n+str(deg),obj,m,b)
# Full-turn check in stowed and raised positions; housing well is rotationally symmetric.
for deg in range(0,360,10):
    for n,it in [('wheel',wheel),('raised grip',fold(knob,90)),('raised stem',fold(stem,90)),('closed grip',knob),('end',end),('hinge head',phead)]:
        obj=it.rotate((RIGHT,0,AXIS_Z),(RIGHT+1,0,AXIS_Z),deg)
        clear(n+str(deg),obj,'housing',base)
        clear(n+str(deg),obj,'bezel',lid)
# Verify folded geometry is inside even the rolled edges of the case.
for n,it in [('rotor',wheel),('grip',knob),('hinge',pin.union(phead)),('stem',stem),('retainer',end)]:
    assert volume(it.cut(outer)) < .002,n
allitems={**parts,**ref}
for i,(n,it) in enumerate(allitems.items()):
    for m,b in list(allitems.items())[i+1:]:clear(n,it,m,b)
# Compare all component solids from the vendor STEP to each printed part and reserved purchased component.
fixed_boxes={n:bbox(v) for n,v in allitems.items()}
conflicts=[]
for obj in board_solids:
    bb=obj.BoundingBox()
    for n,it in allitems.items():
        if overlaps(bb,fixed_boxes[n]):
            common=obj.intersect(it.val()).Volume()
            if common>.002:conflicts.append((n,round(common,3),[round(i,2) for i in (bb.xmin,bb.xmax,bb.ymin,bb.ymax,bb.zmin,bb.zmax)]))
assert not conflicts,conflicts[:20]
print('Vendor board fit checked:',len(board_solids),'solids',flush=True)
proxy=rr(0,0,26.9,92.44,61,1.6,6)
pcb=rr(0,0,21,78,54.5,1.6,1.5)
colors=['#A2B9A9','#2D4441','#365A56','#CE885D','#E39A5C','#537772']
for deployed in [False,True]:
    ass=cq.Assembly(name='Riffle_Pocket_D')
    for (n,it),col in zip(parts.items(),colors):
        shape=fold(it,90) if deployed and n in ('folding-stem','grip') else it
        ass.add(shape,name=n,color=cq.Color(col))
        mesh(shape,dest/'views'/((n+'-open' if deployed and n in ('folding-stem','grip') else n)+'.stl'))
        if not deployed:
            orient=it
            if n=='bezel':orient=it.rotate((0,0,0),(1,0,0),180)
            if n in ('rotor','collar'):orient=it.rotate((0,0,0),(0,1,0),90)
            if n in ('grip','folding-stem'):orient=it.rotate((0,0,0),(1,0,0),90)
            p=dest/'print'/(n+'.stl');mesh(orient,p)
            tri=trimesh.load_mesh(p);tri.apply_translation((-tri.bounds[:,0].mean(),-tri.bounds[:,1].mean(),-tri.bounds[0,2]));tri.export(p)
            assert tri.is_volume and tri.is_watertight and len(tri.split())==1,n
    for n,it in {**ref,'glass reference':proxy,'board reference':pcb}.items():
        ob=fold(it,90) if deployed and n=='grip retainer' else it
        ass.add(ob,name=n,color=cq.Color('#646E66'));mesh(ob,dest/'views'/((n+'-open' if deployed and n=='grip retainer' else n)+'.stl'))
    ass.export(str(dest/('Reeling.step' if deployed else 'Pocket.step')))
data={'stowed_mm':[W,D,H],'folded_grip_recess_mm':round(RIGHT-bbox(knob).xmax,2),'deployed_width_mm':round(50+bbox(fold(end,90)).xmax,2),'axle_direction':'right edge +X','crank_throw_mm':R,'plastic_volume_cm3':round(sum(volume(v) for v in parts.values())/1000,2),'vendor_solids':len(board_solids)}
print(data);(dest/'Checks.json').write_text(json.dumps(data,indent=2))





