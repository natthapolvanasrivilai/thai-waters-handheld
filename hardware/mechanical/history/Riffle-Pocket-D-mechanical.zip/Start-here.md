# Riffle Pocket D | Right-side folding reel

With the display facing the player in landscape, the spindle exits the right sidewall. The player pulls the grip out to the right and reels in a plane parallel to that wall. The grip folds into the rotor through 90 degrees. The back carries speaker vents and recessed board screws.

| Dimension | Rev D |
| --- | --- |
| Pocket envelope including the folded reel | 108.5 x 69 x 30 mm |
| Fishing envelope including the extended grip and retainer | 121.6 x 69 x 30 mm |
| Folded grip behind the right-side tangent plane | About 1.2 mm |
| Wheel diameter / throw | 25.5 mm / 7.8 mm |
| Corner radius / face-edge radius | 10 mm / 4.5 mm |

The right-hand bay adds 8.5 mm to the width of Revision C. The screen and USB connector retain their board registration. The magnet turns on the left-to-right axis, with the AS5600 facing its inboard end. A shallow scoop gives access to the free-spinning grip. Hinge friction provides closed retention and the printed heel limits overtravel when opened.

## Files

The two CAD assemblies show the fully folded and fully deployed positions. The six STL files are the matched mechanical parts for this revision. The electronic references in the assemblies are simplified. To regenerate and run the board fit checks, use Python 3.11 with CadQuery 2.8 and trimesh 5 and run `python right_reel.py path/to/ESP32-S3-Touch-LCD-3_5B.stp output-directory`. The bare 31137 board's mechanical download is in [Waveshare's hardware resources](https://docs.waveshare.com/ESP32-S3-Touch-LCD-3.5B/Resources-And-Documents).

## Design checks

The model checks the grip, stem and retainer during opening in five-degree increments, and samples a full revolution in ten-degree increments. The folded hardware is also checked against the rounded outer case volume. The electronics fit check tests the 546 solids in the supplier board STEP against the printed components and reserved volumes. Printed supports, wires, fabric snagging, fingertip access and hinge friction require a physical trial.

Use the same purchased component set as the Revision C prototype, including the Waveshare 31137, AS5600 breakout, protected 1200 mAh cell and 6 x 2.5 mm diametric magnet. The source keeps a speaker allowance of 15 x 30 x 7 mm and a sensor PCB allowance of 25.4 x 17.8 x 1.6 mm. Check connector projections and wire bends on the received parts.

### One-unit assembly

1. Print housing, bezel, rotor, folding stem, grip and collar. Start at 0.20 mm layers with a 0.4 mm nozzle and three perimeters. Review the recessed wheel well, board screw counterbores and the rotor in the slicer for locally removable support. The stem benefits from tough filament and a brim or a revised orientation if layer adhesion is poor. Clean the bearings and hinge holes.
2. Slip the grip over the stem. Install the small end washer and M2 x 5 screw. Seat the washer against the axle end. The grip must turn freely. Put one 0.25-0.30 mm nylon shim on each side of the stem at the hinge and fit the M2 x 10 pivot screw through the clearance cheek into the far pilot. Adjust until the handle stays stowed during a pocket draw and does not collapse under normal finger pressure. Excess torque can strip the printed cheek.
3. Bond the 6 x 2.5 mm magnet into the round shaft pocket, flush with the pocket seat as modeled. Insert the complete rotor through the right side of the open housing. Bond the loose collar to the shaft **inside the open housing** with a small drop on the shaft/collar interface. Keep adhesive away from the housing bearing. Set the collar with a temporary 0.3-0.4 mm shim against the housing, remove the shim after cure, and check rotation. A scrap test helps establish screw fit and adhesive compatibility for your material.
4. Mount the AS5600 vertically with its IC centered on the right-side spindle axis and facing the magnet. Shim the breakout on its two pads to a nominal 1.2 mm chip-to-magnet face gap. Use the sensor's magnet-detect and field-strength diagnostics while turning through 360 degrees, then fix the breakout. Verify centering under side load. A 6 mm target is alignment-sensitive. Leave room for its I2C lead. For the first unit the solder pads allow lower-profile wiring than vertical headers.
5. Place the included speaker over the rear vents using a thin acoustic gasket. Locate the protected 1200 mAh cell between the rails. Route its leads up into the free cavity and provide strain relief. Use removable foam tape for the cell and avoid compressing it when the board is installed.
6. Power the board from USB first. Use the board-revision pinout to connect 3.3 V, ground, SDA and SCL to the angle breakout. Confirm the encoder, IMU, touch panel and codec individually. The protected Adafruit pack has a JST-PH plug. The Waveshare battery header is MX1.25. Check the keyed adapter and polarity at the board end with a meter before connecting the cell. Configure the AXP2101 for a 4.2 V single cell. A 300 mA initial charge setting is within this cell maker's 500 mA maximum. Check the actual programmed current and termination before enclosed charging.
7. Lower the board onto the four mounting posts with USB facing the left tunnel. Fasten from the rear with four M2 x 8 screws. Verify the received threaded standoff accepts about 2 mm engagement. Check USB data, power-button access and cable reach. Apply thin removable tape to the outer shell rim to hold the bezel. Keep adhesive off the active screen. Allow the lens its nominal 0.25 mm axial clearance.

### First physical checks

Test the bare reel for 100 opening cycles and ten pocket insertion/removal cycles in the clothes it will be carried in. Check for accidental opening, exposed fasteners, fabric snagging, contact with the opening lip, bearing play and any layer cracks. Those are first-unit screening targets. Check that an unfamiliar player can find the finger scoop and land a fish while supporting the screen. A successful fit check alone does not establish long-term wear.

