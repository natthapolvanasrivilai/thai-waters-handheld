# Riffle Wide | Mechanical prototype B

A landscape fishing game held like a small monitor. The left hand supports the rim and grooved back. The right hand turns the edge reel. Pitching the entire unit changes the rod angle. Four side screws leave the face clear. The sample screen is an illustration of the proposed gameplay.

## Size and weight

| Feature | Nominal size |
| --- | --- |
| Housing | 90 x 60 x 21 mm |
| Parked assembly, including fastener heads | 108.3 mm wide x 62.6 mm deep x 27.3 mm high |
| Active pixel area | 82 x 52 mm, approximately 3.82 inches diagonal |
| Active share of nominal rectangular face | 78.96% |
| Display module allowance | 84.8 x 54.9 x 3.3 mm, 2.5 mm corner radius |
| Reel wheel / knob | 24 mm wheel diameter, 10 mm throw, 8.8 mm diameter free-spinning knob |
| Five printed bodies | 26.37 cubic centimeters, about 32.7 g at a fully dense PLA assumption of 1.24 g per cubic centimeter |

The display dimensions are a design target. Actual module borders, driver or flex tail space and connector location could change the bezel or body dimensions. Total device weight also includes that display, the cell, the board, wiring and fasteners.

## Interaction and mechanical checks

- **Support and reel.** A left thumb represented by a 6 mm-radius pad centered between X=-44 and -41 mm can cover up to 6 mm of the active image. Keep essential indicators at least 7 mm inboard on the left. Verify this with the intended player's hand and normal grip. The back has two sets of shallow tactile grooves.
- **Turn the reel.** The 10 mm crank and 4.4 mm-radius knob leave 0.9 mm nominal clearance above a flat desk throughout a full turn. The other tested combinations, 12 mm throw with a 5 mm-radius knob and 16 mm throw with a 6.5 mm-radius knob, dip below the desk. Finger clearance below the wheel still requires holding the game up while reeling.
- **Lift, lower and cast.** Synthetic tilt traces produced one lift and one lower when crossing +22 and -12 degrees, with neutral rearming within 6 degrees. Steady reeling with up to 5 degrees of pitch variation produced zero tilt events. A fast cast trace produced one cast and a slow return produced zero. These candidate thresholds require measurement with a real user and sensor.
- **Read the screen while tilting.** For an eye line centered horizontally and 50 degrees above horizontal, the -15 to +35 degree pitch range produces a worst-case viewing angle of 55 degrees off normal. With the pixel surface at Z=19.8 mm, the flared bezel clears the central longitudinal edge ray by at least 0.29 mm. Side viewing, real display contrast, glass stack tolerances and panel variation need a physical check.
- **Plug in.** The top-edge USB opening is 11.2 x 5.2 mm. The cable exit is separated by 11 mm along the body from the sweep of a modeled 9 mm-radius reeling fingertip. Verify the overmold of the selected cable.
- **Mechanical verification.** The CAD build checks pairwise solid intersections at the parked position, including the component envelopes, then sweeps the reel against the shell at five-degree increments. Each printable STL is a single closed solid with its lowest point at Z=0. These are geometry and scripted motion checks. Functional play, mechanical durability and power use still need a physical prototype.

## Print and assemble the handling mockup

1. Import the five STLs individually in millimeters and retain their orientations. Use a first-pass profile such as a 0.4 mm nozzle and 0.2 mm layers. Inspect the underside of the horizontal axle, USB opening and audio vents in the slicer. Provide local support under the axle as needed. The housing prints back-down and the bezel face-down. The reel prints with its outer face down. Keep support material out of the bearing holes.
2. For a screen trial, print Screen-insert.png at **84.8 x 54.9 mm** (254 pixels per inch) and trim the corners to fit the bezel. Tape it temporarily behind the opening. This lets you check the actual game view and how much your thumb covers with an empty case.
3. Slip the wheel over the fixed right-side axle, with its magnet pocket facing inward. The axle is 5.5 mm in diameter and the bore 5.96 mm. Secure it with an M2.5-compatible, 8 mm thread-forming screw and a clearance washer about 7.8 mm OD and 0.55 mm thick. Seat the washer against the axle end. Nominal wheel end play is 0.55 mm.
4. Insert the 4.0 mm OD sleeve through the knob's 4.48 mm bore. Screw the sleeve to the off-center wheel hole with an M2-compatible, 14 mm thread-forming screw and a clearance washer about 5.7 mm OD and 0.45 mm thick. The clamped sleeve leaves about 0.6 mm of axial clearance for the knob.
5. Lower the bezel tabs into the sidewall notches and secure them with four M2-compatible, 6 mm thread-forming screws. The holes in the housing use nominal 1.66 mm pilots. Confirm screw fit in your chosen filament before tightening. The four fasteners enter along the top and bottom edges of the landscape unit.

## Electronics interfaces for the next pass

| Function | Mechanical provision and remaining decision |
| --- | --- |
| Screen and power | Select a monochrome pixel module that meets the active area, package, readability and power targets. Compare a reflective or memory LCD against the intended lighting and animation rate. The front lip locates the panel. Final support pads, flex routing and retention depend on the actual module. |
| Charging and programming | A shared USB-C nose opening, a 20 x 22 x 2.2 mm logic-board envelope and a connector volume reserve the physical route for both functions. Select a USB data-capable controller and suitable charging circuit. |
| Battery and motion | The rear cavity reserves 31 x 23 x 7 mm for a cell and 4 x 4 x 2 mm above the logic board for a motion sensor. Specify cell restraint, leads and rigid board mounting once the parts are known. |
| Reel sensing | An optional 3.2 mm diameter x 2.2 mm deep magnet pocket sits 8 mm off the wheel axis. At alignment, its mouth is about 3.15 mm from the reserved sensor face through the sidewall. A single magnet and switch can supply one pulse per revolution. Finer tracking or direction sensing needs a different target or sensor. |
| Audio | Four slots on the upper left side face an 8 x 15 x 8 mm transducer allowance. Evaluate a bite beep or short game sounds and check audibility with the left hand in place. |
| Runtime | Candidate behaviors include display sleep, sensor wake-up, and short audio cues. The display choice, measured current in each mode and usable cell capacity determine runtime. |

## Files and reproducibility

Open the named STEP assembly for the editable solids. Hide the component-envelope and fastener-head group when inspecting the enclosure alone. The source folder contains the parametric model and the scenario script. Run the model with Python 3.11, CadQuery 2.8, trimesh 5 and an output directory argument. The scenario script uses the Python standard library. Numerical outputs are in the checks folder.
