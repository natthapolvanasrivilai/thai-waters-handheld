"""Screen-first handheld: kinematic use cases before CAD. Units mm and degrees."""
import json, math
from pathlib import Path
points=range(360)
z=15.3
checks=[]
for throw,knob_r in [(10,4.4),(12,5),(16,6.5)]:
    lowest=min(z+throw*math.sin(math.radians(a))-knob_r for a in points)
    checks.append(dict(throw=throw,knob_radius=knob_r,desk_gap=round(lowest,2)))
assert checks[0]['desk_gap']>0 and checks[1]['desk_gap']<0
view={}
for pitch in [-15,0,35]:
    incidence=abs(40-pitch)
    tangent=math.tan(math.radians(incidence))
    # Eye centered left-to-right. Panel top 19.8; inner and outer aperture shoulders.
    margins=[(53-52)/2-(19.9-19.8)*tangent,(56-52)/2-(21-19.8)*tangent]
    view[pitch]=dict(incidence=incidence,edge_margin=round(min(margins),3))
assert min(x['edge_margin'] for x in view.values())>0
thumb={'left_edge_x':-41,'assumed_thumb_x':[-44,-41],'pad_radius':6,
       'max_overlap':6,'hud_inset':7}
assert thumb['assumed_thumb_x'][1]+6<=thumb['left_edge_x']+thumb['hud_inset']
# A 9 mm right-fingertip proxy follows the crank around X. Nose plug sticks out at Y=30.
pivot_y=0; throw=10
nose_gap=30-(pivot_y+throw+9)
def gesture(trace):
    state='level';events=[]
    for p in trace:
        if state=='level' and p>=22:state='raised';events.append('lift')
        elif state=='level' and p<=-12:state='lowered';events.append('lower')
        elif abs(p)<=6:state='level'
    return events
lift=gesture([0,8,28,31,15,3,-6,-15,-4,0])
reel=gesture([0,3,-4,4,-3,5,0]*6)
def cast(trace):
    armed=False;events=0
    for a,b in zip(trace,trace[1:]):
        if a>=25:armed=True
        if armed and b<=6 and (b-a)/.05<=-120:events+=1;armed=False
        elif b<0:armed=False
    return events
casts=[cast(t) for t in ([0,10,28,31,20,5,-9,1],[0,12,28,26,22,18,14,10,6,2,-2])]
assert lift==['lift','lower'] and not reel and casts==[1,0]
print(json.dumps(dict(screen_fraction=82*52/(90*60),sweeps=checks,view=view,thumb=thumb,
                      cable_gap=nose_gap,tilt=lift,steady_reel=reel,fast_and_slow_casts=casts),indent=2))

