"""Riffle Wide, mechanical Rev B. Python 3.11, CadQuery 2.8 and trimesh 5. Units mm."""
from pathlib import Path
import math, sys, json
import cadquery as cq
import trimesh
from cadquery import Vector
W,D,H=90.,60.,21.
PZ=15.3
R=10.
def box(x,y,z,w,d,h):
    return cq.Workplane('XY').box(w,d,h,centered=(True,True,False)).translate((x,y,z))
def xy(x,y,z,w,d,h,r):
    return box(x,y,z,w,d,h).edges('|Z').fillet(r)
def cx(x,y,z,h,r):
    return cq.Workplane(obj=cq.Solid.makeCylinder(r,h,Vector(x,y,z),Vector(1,0,0)))
def cy(x,y,z,h,r):
    return cq.Workplane(obj=cq.Solid.makeCylinder(r,h,Vector(x,y,z),Vector(0,1,0)))
def wire(w,d,r,z):
    return xy(0,0,z-1,w,d,1,r).faces('>Z').wires().val()
def shell():
    base=xy(0,0,0,W,D,18.8,5.2).edges('<Z').fillet(1.6)
    base=base.cut(xy(0,0,2.2,W-3.6,D-3.6,17,3.4))
    for x in [-33,33]:
        for y in [-12,-6,0,6,12]:
            base=base.cut(xy(x,y,-.1,13,2.2,.8,1.05))
    # Single USB-C cutout on far edge and audio vents in the left edge near the top.
    base=base.cut(box(0,29,6.5,11.2,7,5.2).edges('|Y').fillet(1.7))
    for y in [12,14.8,17.6,20.4]:
        base=base.cut(box(-44,y,8,6,1.3,6.8).edges('|X').fillet(.63))
    lid=xy(0,0,18.8,W,D,2.2,5.2).edges('>Z').fillet(.5)
    lid=lid.cut(xy(0,0,18.5,85.5,55.6,1.4,2.3))
    # Flared window through the lip keeps the active image visible when tilted.
    win=cq.Solid.makeLoft([wire(82.8,53,.65,19.89),wire(85.6,56,1.7,21.0)],True)
    lid=lid.cut(cq.Workplane(obj=win)).cut(xy(0,0,21,85.6,56,1,1.7))
    for x in [-28,28]:
        for sign in [-1,1]:
            base=base.cut(box(x,sign*29.0,8.8,8.5,3,12))
            boss=box(x,sign*25.05,2.0,8.4,5.9,13.7)
            base=base.union(boss).cut(cy(x,22 if sign>0 else -30,12.6,8,.83))
            tongue=box(x,sign*29.0,9.05,8,2,10.6)
            lid=lid.union(tongue).cut(cy(x,26 if sign>0 else -31,12.6,6,1.15))
    # Fixed side axle carries the reel load without intruding on the display.
    # The plinth footprint bridges the seam only outside the housing.
    base=base.union(cx(45,0,PZ,2.05,4.5)).union(cx(47.05,0,PZ,5.05,2.75))
    base=base.cut(cx(43.95,0,PZ,8.5,1.04))
    return base,lid
def reel():
    wheel=cx(47.3,0,PZ,4.5,12).edges('>X or <X').fillet(.72)
    wheel=wheel.cut(cx(46,0,PZ,8,2.98))
    for s in [-1,1]:
        wheel=wheel.cut(cx(46,0,PZ+s*7,7,2.7))
    wheel=wheel.union(cx(45.7,-8,PZ,2,2.4)).cut(cx(45.5,-8,PZ,2.4,1.6))
    wheel=wheel.cut(cx(47.75,R,PZ,5,.82))
    sleeve=cx(51.8,R,PZ,9.6,2.0).cut(cx(51.5,R,PZ,11,1.1))
    knob=cx(52.1,R,PZ,9.,4.4).edges('>X or <X').fillet(1.05)
    knob=knob.cut(cx(51.5,R,PZ,11,2.24))
    for i in range(14):
        a=i*math.tau/14
        knob=knob.cut(cx(51,R+4.65*math.cos(a),PZ+4.65*math.sin(a),12,.45))
    return wheel,sleeve,knob
def build(dest):
    dest=Path(dest); refdir=dest/'reference'; printdir=dest/'print'
    for p in [refdir,printdir]:p.mkdir(exist_ok=True,parents=True)
    base,lid=shell()
    wheel,sleeve,knob=reel()
    parts=dict(housing=base,bezel=lid,reel=wheel,sleeve=sleeve,knob=knob)
    refs={'panel':xy(0,0,16.5,84.8,54.9,3.3,2.5),
          'battery':box(-11,-10,4.5,31,23,7),
          'logic':box(2,14,4.7,20,22,2.2),
          'usb':box(0,26,6.9,9.4,8,4.2),
          'imu':box(7,14,6.9,4,4,2),
          'audio':box(-38,16,6,8,15,8),
          'reel sensor':box(41.25,-8,11.8,2.6,8,4.5)}
    refs['axle washer']=cx(52.1,0,PZ,.55,3.9).cut(cx(52,0,PZ,.9,1.35))
    refs['axle head']=cx(52.65,0,PZ,1.6,2.25)
    refs['knob washer']=cx(61.4,R,PZ,.45,2.85).cut(cx(61.25,R,PZ,1,1.05))
    refs['knob head']=cx(61.85,R,PZ,1.45,1.75)
    for x in [-28,28]:
        for sign in [-1,1]:
            h=cy(x,30 if sign==1 else -31.3,12.6,1.3,1.75)
            notch=box(x,sign*31.35,12.35,2.1,.7,.5)
            refs[f'edge screw {x} {sign}']=h.cut(notch)
    assembly=cq.Assembly(name='Riffle_Wide_B')
    colors=['#78968B','#263C3D','#315C58','#8E7760','#D77741']
    for (name,item),color in zip(parts.items(),colors):
        assert item.val().isValid() and len(item.solids().vals())==1,name
        assembly.add(item,name=name,color=cq.Color(color))
        cq.exporters.export(item,str(refdir/(name+'.stl')),tolerance=.035,angularTolerance=.1)
        m=item
        if name=='bezel':m=item.rotate((0,0,0),(1,0,0),180)
        if name in ['reel','sleeve','knob']:m=item.rotate((0,0,0),(0,1,0),90)
        path=printdir/(name+'.stl')
        cq.exporters.export(m,str(path),tolerance=.035,angularTolerance=.1)
        mesh=trimesh.load_mesh(path)
        mesh.apply_translation((-mesh.bounds[:,0].mean(),-mesh.bounds[:,1].mean(),-mesh.bounds[0,2]))
        mesh.export(path)
        mesh=trimesh.load_mesh(path)
        assert mesh.is_volume and mesh.is_watertight and len(mesh.split())==1 and abs(mesh.bounds[0,2])<.001,name
    group=cq.Assembly(name='Component_envelopes_and_fastener_heads')
    for name,item in refs.items():
        group.add(item,name=name,color=cq.Color('#484F49' if name=='panel' else '#9CA699'))
        cq.exporters.export(item,str(refdir/(name+'.stl')),tolerance=.04,angularTolerance=.12)
    assembly.add(group)
    assembly.export(str(dest/'Riffle-Wide-B.step'))
    allitems=list(parts.items())+list(refs.items())
    for i,(n,it) in enumerate(allitems):
        for n2,it2 in allitems[i+1:]:
            a=it.val().BoundingBox();b=it2.val().BoundingBox()
            if a.xmax<=b.xmin or b.xmax<=a.xmin or a.ymax<=b.ymin or b.ymax<=a.ymin or a.zmax<=b.zmin or b.zmax<=a.zmin:continue
            vol=it.val().intersect(it2.val()).Volume()
            assert vol<.001,(n,n2,vol)
    fixed=base.union(lid).val()
    for deg in range(0,360,5):
        rot=wheel.val().rotate((0,0,PZ),(1,0,PZ),deg)
        assert rot.intersect(fixed).Volume()<.001,deg
    sizes={n:round(it.val().Volume()/1000,3) for n,it in parts.items()}
    data=dict(volume_cm3=sizes,plastic_g=round(sum(sizes.values())*1.24,1),step_solids=len(allitems))
    print(json.dumps(data,indent=2))
    (dest/'measurements.json').write_text(json.dumps(data,indent=2))
if __name__=='__main__':build(sys.argv[1] if len(sys.argv)>1 else 'wide-export')


