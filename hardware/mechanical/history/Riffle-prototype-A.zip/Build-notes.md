# Riffle
## Mechanical prototype A

A pocket-size fishing game held lengthwise like a short rod. The left hand grips the tapered handle while the right hand reels. The screen sits ahead of the fingers. The USB port exits through the nose. The five printed parts form a playable-motion mockup. The example pixel screen in the preview illustrates the intended game.

### Open or print

Open Riffle.step in a solid-modeling CAD application. The assembly includes five printable solids and a named group of placeholder electronics and fastener heads. Hide that group to inspect the shell. The print folder contains the five printable parts, each oriented on Z=0 in millimeters. Import them individually at 100% scale and arrange them on the bed.

| Dimension | Rev A |
| --- | --- |
| Enclosure | 120 mm long, 58 mm maximum width, 27 mm high |
| Width including the parked reel and screw head | 79.5 mm |
| Crank radius and knob diameter | 16 mm and 13 mm |
| Shell wall / split above base | 2.2 mm / 21 mm |
| Screen active-area assumption / clear opening | 24 x 13 mm / 26 x 18.6 mm |
| Solid printed volume / mass at assumed PLA density of 1.24 g per cubic centimeter | 45.13 cubic centimeters / 56.0 g |

The mass covers plastic only. Infill, fasteners, components and wiring change the assembled weight. For a provisional 95 g assembled target, the fully dense estimate leaves 39 g for hardware and electronics.

### Use scenarios run before CAD, then checked against the model

| Action | Simulation and result | Design consequence |
| --- | --- | --- |
| Take hold and reel | A 9 mm-radius fingertip proxy follows a full circle. The holding hand is assumed to end 9 mm behind the longitudinal origin. The initial axle location gave 4 mm of overlap with a 16 mm throw. Moving it 6 mm forward gave 2 mm of longitudinal separation. | Use the forward axle position. Print and check this small margin with the intended player's hands and grip. |
| Lift and lower the rod | A scripted pitch trace from level through +31 degrees, neutral, then -15 degrees produced one lift and one lower. Thresholds were +22 and -12 degrees, with rearming within 6 degrees of level. | Calibrate neutral when play starts. Use a separate return-to-neutral band for deliberate repeat gestures. |
| Cast vs. lower slowly | After raising the rod to at least 25 degrees, a fast return through +6 degrees produced one cast. A slow return produced zero. The prototype rule uses a forward rate of at least 120 degrees per second. | Apply cast detection in the game's ready-to-cast state. Use lift and lower during the fight. |
| Reel through a bite | A synthetic steady-reeling trace with pitch variation up to 5 degrees gave zero rod events. A separate lift-during-reeling trace gave one lift. | Keep turn counting independent of pitch. Physical hand wobble and sensor noise still need measurement. |
| Read the pixels while lowering | Assume an eye line 50 degrees above horizontal toward the handle. Over -15 to +35 degrees of body pitch, the worst centered view is 55 degrees off the screen normal. The first window clipped an edge ray by 1.43 mm. The enlarged window clears it by 0.37 mm at the inner step and 1.79 mm at the upper recess. | Fit and center the selected display carefully. Its optical contrast and side-view performance need a live trial. |
| Connect USB or set the game down | The nose cable approach and swept fingertip envelope have 12 mm of separation along the body. At the lowest crank angle the knob extends 7.5 mm below the base. In the nose-facing park position it clears the table by 8.5 mm. | Park the crank horizontally to charge or program on a desk. Spin it with the unit held off the table. |

The finger sweep used one-degree angle increments across six axle and radius combinations. The CAD build also checked the parked parts, shell against component reservations, pairwise electronic volumes and a five-degree crank sweep. The round axle's radial fit is constant through a turn. All five exported print meshes passed closed-volume and single-component checks. These tests evaluate assumed geometry and synthetic input. Grip comfort, printed fits, durability, optical readability and runtime need physical measurements.

### Make the empty-shell mockup

Use a first-pass FDM profile of 0.20 mm layers and three perimeters with a 0.4 mm nozzle. Place the base floor down, lid face down, crank outer face down, and sleeve and knob on end, as exported. Preview the horizontal axle bore and USB opening for bridge quality. Keep the knob bore and sleeve free of support residue.

Nominal hardware for the mockup:

- Four 2.5 x 10 mm plastic-compatible thread-forming screws for the lid, head diameter at most 5.0 mm and height at most 2.3 mm.
- Two 3 mm nominal plastic-compatible thread-forming screws, one 8 mm long for the crank axle and one 16 mm long for the knob.
- One approximately 9 mm OD washer for the axle and one approximately 8 mm OD washer for the knob. Both should have M3 clearance and be about 0.6 mm thick.

1. Print one of each part. Check that the 5.9 mm axle rotates in the nominal 6.5 mm case bore, and the 5.8 mm sleeve rotates freely inside the knob's 6.34 mm bore. Test screw fit in spare material if needed. Actual dimensions depend on the printer and filament.
2. Insert the crank axle through the right side from outside. Fit the larger washer and 8 mm screw from inside. Seat the washer against the end of the axle. The axle shoulder spacing provides 0.7 mm total nominal end play across the bearing.
3. Slide the sleeve into the knob. Place both on the outer crank face over the off-center pilot hole. Add the small washer and 16 mm screw. Tighten onto the sleeve so the knob can spin. It also has 0.7 mm total nominal end play.
4. Fit the empty lid and install the four screws. Hold the device with the thumb clear of the sound slots, reel slowly, then repeat while pitching through your comfortable range. Check finger rub, cable approach, screen sightline and whether the crank binds when the lid is tightened.

### Interfaces for the electronics pass

The following sizes are editable packaging allowances. The electronics still need selection, mounting, wiring and electrical verification.

| Function | Reserved space or mechanical interface |
| --- | --- |
| Monochrome pixel display | 31 x 20 x 4.65 mm envelope under the face. The flat underside around the opening and side guides locate a future retainer. Verify the viewing area, cable exit and mounting method. |
| USB charging and programming | Rounded 11.2 x 5.2 mm nose opening, 20 x 26 x 2.6 mm logic-board envelope and 9.4 x 7.5 x 4 mm connector envelope. Select one USB data-capable controller and rechargeable-cell charge path that share this connector. Confirm the actual plug overmold, board attachment and strain relief. |
| Rechargeable cell | 23 x 34 x 8 mm envelope low in the grip. Size retention, lead routing and allowance for the selected protected cell during integration. |
| Rod motion | 6 x 6 x 2.4 mm package allowance on the logic board. Locate it rigidly to the shell and define pitch along the length of the grip. |
| Reel rotation | The crank has a 3.2 mm diameter, 2.2 mm deep pocket for a future index magnet, offset 9 mm from the axle. An 8 x 8 x 2 mm sensor envelope sits behind the wall, with a nominal 3.05 mm gap to the pocket mouth at alignment. Measure the field with the chosen magnet and sensor. One index gives one pulse per revolution. Direction or finer angular resolution would require a different target. |
| Sound | 15 mm diameter x 5.5 mm transducer allowance under five top slots. Use it to evaluate a short bite beep and optional game sounds. |
| Low power | Design intent is a small monochrome display, event-driven turn counting, wake-on-motion or timed wake, display sleep and short sound cues. Choose the display technology and measure active and sleep current before setting a runtime target. |

The physical mockup can be assessed without buying electronics. A good first trial is ten slow turns, three lifts, three lowers, one cast gesture and a desk USB fit check using the intended cable.

### Reproduce the study

Run source/scenarios.py with Python 3 to reproduce the scripted traces and kinematic envelope results. The numerical output is in checks/scenarios.json. Run source/model.py with a destination directory using Python 3.11, CadQuery 2.8 and trimesh 5. The script generates the assembly, print meshes, reference meshes and volume report, then checks the CAD. Dimensional constants and profile points are at the top of the model.
