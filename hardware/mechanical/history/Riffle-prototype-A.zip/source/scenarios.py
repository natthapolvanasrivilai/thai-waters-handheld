"""Evaluate assumed user motions and spatial envelopes before building the CAD."""
from math import sin, cos, radians, acos, degrees, tan
import json
from pathlib import Path

# Tip points along +Y, reel along +X. Lengths mm, angles degrees.
candidates = []
for pivot_y in (12, 18):
    for radius in (14, 16, 20):
        for pitch in range(-15, 36):
            # Eye 50 degrees above horizontal, towards the player (-Y).
            error = degrees(acos(sin(radians(50))*cos(radians(pitch))+
                                 cos(radians(50))*sin(radians(pitch))))
            if pitch == -15:
                worst = error
        # 9 mm finger proxy about knob axis. Grip envelope ends at Y=-9.
        sweep = [(pivot_y+radius*cos(radians(i)),15+radius*sin(radians(i))) for i in range(360)]
        candidates.append(dict(pivot_y=pivot_y,radius=radius,
            grip_gap=round(min(y-9-(-9) for y,z in sweep),2),
            table_gap=round(min(z-6.5 for y,z in sweep),2),
            parked_table_gap=15-6.5,
            nose_cable_y_gap=round(55-max(y+9 for y,z in sweep),2),
            worst_view_angle=round(worst,2)))
selected = next(c for c in candidates if c['pivot_y']==18 and c['radius']==16)
assert selected['grip_gap'] >= 2 and selected['nose_cable_y_gap'] >= 8
# Traces exercise gesture classification as a design assumption only.
def motion(trace):
    state = 'level'; events = []
    for pitch in trace:
        if state=='level' and pitch>=22: state='raised'; events.append('lift')
        elif state=='level' and pitch<=-12: state='lowered'; events.append('lower')
        elif state!='level' and abs(pitch)<=6: state='level'
    return events
traces = {'lift and lower':[-2,5,18,29,31,20,4,-7,-15,-14,-4,0],
          'steady reeling':[0,3,-4,4,-3,5,0]*6,
          'lift while reeling':[0,4,-3,8,18,26,29,25,27,18,6,0]}
events = {k:motion(v) for k,v in traces.items()}
assert list(events.values()) == [['lift','lower'],[],['lift']]


# A cast starts from a raised position and requires a quick forward pitch.
def cast_count(trace, dt):
    armed = False
    casts = 0
    for a,b in zip(trace, trace[1:]):
        if a >= 25: armed = True
        if armed and b <= 6 and (b-a)/dt <= -120:
            casts += 1
            armed = False
        elif b < 0:
            armed = False
    return casts
casts = [cast_count(t,0.05) for t in ([0,10,28,31,20,5,-9,1], [0,12,28,26,22,18,14,10,6,2,-2])]
assert casts == [1,0]

# Longitudinal ray from the extreme pixel to the two aperture shoulders.
# Compare both the first window and the revised CAD window.
shift = (26.35-24.65)*tan(radians(selected['worst_view_angle']))
old_margin = (15-13)/2-shift
new_margin = (18.6-13)/2-shift
bezel_margin = (23.3-13)/2-(27-24.65)*tan(radians(55))
assert old_margin<0 and min(new_margin,bezel_margin)>0
report=dict(candidates=candidates, selected=selected, tilt_events=events, cast_events=casts,
            old_window_edge_margin_mm=round(old_margin,2),
            revised_window_edge_margin_mm=round(new_margin,2),
            upper_bezel_margin_mm=round(bezel_margin,2))
print(json.dumps(report,indent=2))
