"""Riffle | mechanical study. Python 3.11, CadQuery 2.8, trimesh 5. Units: mm.
Run: python model.py [export directory]. Positive Y points to the USB nose.
"""
from pathlib import Path
import sys, json, math
import cadquery as cq
import trimesh
from cadquery import Vector

WALL = 2.2
HEIGHT = 27.0
SEAM = 21.0
PIVOT_Y, PIVOT_Z = 18., 15.
THROW = 16.
# Right half, from the butt to the nose. Mirroring keeps the grip symmetric.
profile = [(13,-65),(18,-59),(17,-39),(18.8,-23),(22,-13),(29,0),
           (29,46),(22,55)]
outline = profile + [(-x,y) for x,y in reversed(profile)]

def slab(x,y,z,dx,dy,dz):
    return cq.Workplane('XY').box(dx,dy,dz,centered=(True,True,False)).translate((x,y,z))

def pin_x(x,y,z,length,rad):
    return cq.Workplane(obj=cq.Solid.makeCylinder(rad,length,Vector(x,y,z),Vector(1,0,0)))

def pin_z(x,y,z,length,rad):
    return cq.Workplane('XY').workplane(offset=z).center(x,y).circle(rad).extrude(length)

def curved_block(x,y,z,dx,dy,dz,r):
    return slab(x,y,z,dx,dy,dz).edges('|Z').fillet(r)

def body():
    outer = cq.Workplane('XY').polyline(outline).close().extrude(HEIGHT).edges('|Z').fillet(5.5)
    edge = outer.faces('>Z').wires().val().translate((0,0,-HEIGHT))
    inner = edge.offset2D(-WALL)[0]
    cavity = cq.Workplane(obj=cq.Solid.extrudeLinear(inner,[],Vector(0,0,HEIGHT-2*WALL))).translate((0,0,WALL))
    skin = outer.edges('>Z or <Z').fillet(1.6).cut(cavity)
    lower = skin.intersect(slab(0,0,0,160,160,SEAM))
    cover = skin.intersect(slab(0,0,SEAM,160,160,HEIGHT-SEAM))
    for x,y in [(22,43),(-22,43),(11.5,-54),(-11.5,-54)]:
        lower = lower.union(pin_z(x,y,1,SEAM-1,3.65)).cut(pin_z(x,y,11,11,1.05))
        cover = cover.union(pin_z(x,y,SEAM,HEIGHT-SEAM-0.3,3.65))
        cover = cover.cut(pin_z(x,y,SEAM-1,10,1.4)).cut(pin_z(x,y,24.7,5,2.55))
    lower = lower.union(pin_x(23,PIVOT_Y,PIVOT_Z,6,5.5))
    lower = lower.cut(pin_x(22,PIVOT_Y,PIVOT_Z,10,3.25))
    # Flat USB plug approach at the nose.
    port = slab(0,54,6.3,11.2,8,5.2).edges('|Y').fillet(1.65)
    lower = lower.cut(port)
    # Recessed bezel and actual aperture. Under the lid are two lateral guide ribs.
    cover = cover.cut(curved_block(0,27,26.35,33.8,23.3,2,2.4))
    cover = cover.cut(curved_block(0,27,23,26,18.6,6,1.0))
    for x in [-17.15,17.15]:
        cover = cover.union(slab(x,27,23.0,2.5,22,2.1))
    for x in [-4.8,-2.4,0,2.4,4.8]:
        cover = cover.cut(curved_block(x,0,23,1.3,8-abs(x)*.50,7,.64))
    # Shallow grooves provide a directional thumb/palm cue.
    for y,width in [(-25,21),(-30,20),(-35,19),(-40,18)]:
        cover = cover.cut(curved_block(0,y,26.45,width,1.6,2,.78))
    return lower, cover

def reel():
    y,z = PIVOT_Y,PIVOT_Z
    # Arm is parked facing the nose. Both axles point along X.
    arm = cq.Workplane('YZ',origin=(31,y+THROW/2,z)).slot2D(THROW+11,11,0).extrude(4.5)
    arm = arm.edges('>X or <X').fillet(.6)
    arm = arm.union(pin_x(29.3,y,z,2,5)).union(pin_x(22.6,y,z,7.0,2.95))
    arm = arm.cut(pin_x(22,y,z,9.6,1.25)).cut(pin_x(30.8,y+THROW,z,5,1.25))
    # Optional single index target faces a sensor across the side wall.
    target_y = y+9
    arm = arm.union(pin_x(29.6,target_y,z,1.8,2.65)).cut(pin_x(29.4,target_y,z,2.4,1.6))
    sleeve = pin_x(35.5,y+THROW,z,12.4,2.9).cut(pin_x(35,y+THROW,z,14,1.65))
    knob = pin_x(35.85,y+THROW,z,11.7,6.5).edges('>X or <X').fillet(1.65)
    knob = knob.cut(pin_x(35,y+THROW,z,14,3.17))
    for i in range(12):
        a=math.radians(i*30)
        knob=knob.cut(pin_x(34,y+THROW+6.95*math.cos(a),z+6.95*math.sin(a),16,.68))
    return arm, sleeve, knob

def generate(dest):
    dest=Path(dest)
    for sub in ['print','reference']: (dest/sub).mkdir(parents=True,exist_ok=True)
    lower,cover=body()
    arm,sleeve,knob=reel()
    parts=dict(base=lower,lid=cover,crank=arm,bushing=sleeve,knob=knob)
    # In the closed STEP these are space reservations, removable as a group.
    refs={'display envelope':slab(0,27,20,31,20,4.65),
          'cell envelope':slab(0,-32,3.2,23,34,8),
          'logic and USB board':slab(0,39,4,20,26,2.6),
          'USB connector':slab(0,51.25,6.6,9.4,7.5,4.0),
          'reel sensor envelope':slab(25.55,PIVOT_Y+10,11,2,8,8),
          'audio envelope':pin_z(0,0,19,5.5,7.5),
          'motion sensor envelope':slab(-5,38,6.6,6,6,2.4)}
    # Nominal washer/screw profiles convey retention, kept out of print exports.
    def washer(x,y,ro):
        return pin_x(x,y,PIVOT_Z,.6,ro).cut(pin_x(x-.2,y,PIVOT_Z,1,1.65))
    refs['axle washer']=washer(22.0,PIVOT_Y,4.5)
    refs['knob washer']=washer(47.9,PIVOT_Y+THROW,4.)
    refs['axle screw head']=pin_x(20,PIVOT_Y,PIVOT_Z,2,2.8)
    refs['knob screw head']=pin_x(48.5,PIVOT_Y+THROW,PIVOT_Z,2,2.8)
    for i,(x,y) in enumerate([(22,43),(-22,43),(11.5,-54),(-11.5,-54)]):
        head=pin_z(x,y,24.7,1.7,2.25)
        cross=slab(x,y,25.95,2.5,.55,1).union(slab(x,y,25.95,.55,2.5,1))
        refs[f'lid screw head {i+1}']=head.cut(cross)
    colors=['#1E5555','#E6DCC1','#263E41','#977957','#DC7644']
    assy=cq.Assembly(name='Riffle')
    for (name,item),color in zip(parts.items(),colors):
        assert item.val().isValid() and len(item.solids().vals())==1,name
        assy.add(item,name=name,color=cq.Color(color))
        cq.exporters.export(item,str(dest/'reference'/(name+'.stl')),tolerance=.045,angularTolerance=.09)
        printable=item
        if name=='lid': printable=item.rotate((0,0,0),(1,0,0),180)
        if name in ['crank','knob','bushing']: printable=item.rotate((0,0,0),(0,1,0),90)
        box=printable.val().BoundingBox()
        printable=printable.translate((-(box.xmin+box.xmax)/2,-(box.ymin+box.ymax)/2,-box.zmin))
        path=dest/'print'/(name+'.stl')
        cq.exporters.export(printable,str(path),tolerance=.045,angularTolerance=.09)
        mesh=trimesh.load_mesh(path)
        # Tessellated and analytic bounding boxes can differ slightly on fillets.
        mesh.apply_translation((0,0,-mesh.bounds[0,2]))
        mesh.export(path)
        mesh=trimesh.load_mesh(path)
        assert mesh.is_watertight and mesh.is_volume and len(mesh.split())==1,name
    refassy=cq.Assembly(name='study_envelopes_and_fastener_heads')
    for name,item in refs.items():
        cq.exporters.export(item,str(dest/'reference'/(name+'.stl')),tolerance=.045,angularTolerance=.12)
        refassy.add(item,name=name,color=cq.Color('#474C46' if 'display' in name else '#94A39A'))
    assy.add(refassy)
    assy.export(str(dest/'Riffle.step'))
    # Check intersections of the as-parked parts and reserved electronic volumes.
    fixed=lower.union(cover).val()
    clearance={}
    for name,it in parts.items():
        for name2,it2 in parts.items():
            if name<name2:
                assert it.val().intersect(it2.val()).Volume()<.001,(name,name2)
    for name,obj in refs.items():
        v=fixed.intersect(obj.val()).Volume()
        assert v<.001,(name,v)
    electronics=[v for k,v in refs.items() if 'head' not in k and 'washer' not in k]
    for i,obj in enumerate(electronics):
        for other in electronics[i+1:]:
            assert obj.val().intersect(other.val()).Volume()<.001
        for moving in (arm,sleeve,knob):
            assert obj.val().intersect(moving.val()).Volume()<.001
    # The only moving shape that enters the body envelope is the round axle.
    # Its radial fit is invariant. Sweep the remaining shapes against both shells.
    # Test rigidly rotated simplified bounds for arm and knob plus invariant axle.
    for a in range(0,360,5):
        for name,item in [('crank',arm),('knob',knob)]:
            rot=item.val().rotate((0,PIVOT_Y,PIVOT_Z),(1,PIVOT_Y,PIVOT_Z),a)
            if rot.BoundingBox().xmin>29.001: continue
            common=rot.intersect(fixed).Volume()
            assert common<.001,(a,name,common)
    data={name:round(item.val().Volume()/1000,3) for name,item in parts.items()}
    details={'volume_cm3':data,'total_cm3':round(sum(data.values()),3),'assumed_PLA_g_cm3':1.24,
             'fully_dense_plastic_g':round(sum(data.values())*1.24,1)}
    print(json.dumps(details,indent=2))
    (dest/'volume.json').write_text(json.dumps(details,indent=2))
    return parts,refs
if __name__=='__main__':
    generate(sys.argv[1] if len(sys.argv)>1 else 'export')





